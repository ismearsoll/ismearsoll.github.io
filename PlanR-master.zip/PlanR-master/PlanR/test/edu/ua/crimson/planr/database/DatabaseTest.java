package edu.ua.crimson.planr.database;

import static org.junit.Assert.*;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

import org.bson.Document;
import org.junit.Test;

import com.google.gson.Gson;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import edu.ua.crimson.planr.model.event.Event;
import edu.ua.crimson.planr.model.event.user.impl.Admin;

/**
 * Tests the Database class.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class DatabaseTest {

	/**
	 * The MongoDB host.
	 */
	private static final String MONGODB_HOST = "localhost";

	/**
	 * The MongoDB port.
	 */
	private static final int MONGODB_PORT = 27017;

	/**
	 * The MongoDB client.
	 */
	private static final MongoClient CLIENT = new MongoClient(MONGODB_HOST, MONGODB_PORT);

	/**
	 * The PlanR database.
	 */
	private static final MongoDatabase PLANR_DATABASE = CLIENT.getDatabase("planr");

	/**
	 * The users test collection.
	 */
	private static final MongoCollection<Document> TEST_USERS = PLANR_DATABASE.getCollection("users_dev");

	/**
	 * The events test collection.
	 */
	private static final MongoCollection<Document> TEST_EVENTS = PLANR_DATABASE.getCollection("events_dev");

	/**
	 * The registration test name.
	 */
	private static final String REGISTRATION_NAME = "desmond";

	/**
	 * The registration test correct password.
	 */
	private static final String REGISTRATION_CORRECT_PASSWORD = "password";

	/**
	 * The registration test incorrect password.
	 */
	private static final String REGISTRATION_INCORRECT_PASSWORD = "bob";

	/**
	 * The registration test new user.
	 */
	private static final String REGISTRATION_NEW_NAME = "new_desmond";

	/**
	 * The registration test new password.
	 */
	private static final String REGISTRATION_NEW_PASSWORD = "new_password";

	/**
	 * The test event name.
	 */
	private static final String EVENT_NAME = "newEvent";

	@Test
	public void testRegistrationFind() {
		Document document = getRegisteredUserByName(REGISTRATION_NAME);
		assertTrue(document.get("uid").equals("abc"));
	}

	@Test
	public void testRegistrationPassword() {
		Document document = getRegisteredUserByName(REGISTRATION_NAME);

		if (document != null) {
			String password = (String) document.get("password");

			assertTrue(!password.equals(hash(REGISTRATION_INCORRECT_PASSWORD)));
			assertTrue(password.equals(hash(REGISTRATION_CORRECT_PASSWORD)));
		}
	}

	@Test
	public void testRegistrationNewUser() {
		Document document = getRegisteredUserByName(REGISTRATION_NEW_NAME);

		if (document == null)
			registerNewUser(REGISTRATION_NEW_NAME, REGISTRATION_NEW_PASSWORD);

		assertTrue(getRegisteredUserByName(REGISTRATION_NEW_NAME) != null);

	}

	@Test
	public void testFindEvent() {
		Event event = getEventByName(EVENT_NAME);

		assertTrue(event.getName().equals(EVENT_NAME));

	}

	@Test
	public void testAddEvent() {
		Event event = Event.Builder.newBuilder().withName("newEvent").build();

		if (getEventByName("newEvent") == null) {
			addNewEvent(event);
		}

		assertTrue(getEventByName(event.getName()) != null);
	}

	@Test
	public void testUpdateEvent() {
		Event event = Event.Builder.newBuilder().withName("newEvent").build();
		
		Event event2 = event.toBuilder().withName("LOL").
				addAdmin(Admin.Builder.newBuilder()
						.withName("james")
						.build())
				.build();
		
		updateEvent(event, event2);
	}
	
	@Test
	public void testFindAllEvents() {
		MongoCursor<Document> iterator = TEST_EVENTS.find().iterator();
		
		while (iterator.hasNext()) {
			Document document = iterator.next();
			
			assertTrue(document != null);
		}
	}


	/**
	 * Registers a new user.
	 * 
	 * @param name The user name
	 * 
	 * @param password The password
	 */
	private static void registerNewUser(String name, String password) {
		BasicDBObject object = new BasicDBObject();

		object.put("uid", UUID.randomUUID().toString());
		object.put("name", name);
		object.put("password", hash(password));

		TEST_USERS.insertOne(Document.parse(object.toJson()));
	}

	/**
	 * Adds a new event to the database.
	 * 
	 * @param event The event
	 */
	private static void addNewEvent(Event event) {
		TEST_EVENTS.insertOne(Document.parse(new Gson().toJson(event)));
	}

	/**
	 * Updates an event.
	 * 
	 * @param oldEvent The old event
	 * 
	 * @param newEvent The new event
	 */
	private static void updateEvent(Event oldEvent, Event newEvent) {

		BasicDBObject search = new BasicDBObject();

		search.put("name", oldEvent.getName());

		Document document = TEST_EVENTS.find(search).first();

		if (document == null)
			return;
		
		TEST_EVENTS.replaceOne(document, Document.parse(new Gson().toJson(newEvent)));
	}

	/**
	 * Gets the registered user by name.
	 * 
	 * @param name The user name
	 * 
	 * @return null if the user was not found
	 */
	private static Document getRegisteredUserByName(String name) {
		BasicDBObject search = new BasicDBObject();

		search.put("name", name);

		return TEST_USERS.find(search).first();
	}

	/**
	 * Gets the event by name.
	 * 
	 * @param name The event name
	 * 
	 * @return null if the event was not found
	 */
	private static Event getEventByName(String name) {
		BasicDBObject search = new BasicDBObject();

		search.put("name", name);

		Document document = TEST_EVENTS.find(search).first();

		if (document == null)
			return null;

		return new Gson().fromJson(document.toJson(), Event.class);
	}
	
	/**
	 * Hashes a password.
	 * 
	 * @param password The password
	 * 
	 * @return The hashed password
	 */
	private static String hash(String password) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			byte[] digest = md.digest((password + "salt").getBytes());
			BigInteger integer = new BigInteger(1, digest);
			String hash = integer.toString(16);
			
			while (hash.length() < 32)
				hash = "0" + hash;
			
			return hash;
			
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
