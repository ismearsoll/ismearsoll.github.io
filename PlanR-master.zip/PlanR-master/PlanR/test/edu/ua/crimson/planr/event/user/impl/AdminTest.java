package edu.ua.crimson.planr.event.user.impl;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ua.crimson.planr.model.event.user.impl.Admin;

/**
 * Tests the Admin class.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class AdminTest {
	
	/**
	 * The admin variable.
	 */
	private static final Admin ADMIN = Admin.Builder.newBuilder()
			.withUID("test")
			.withName("Desmond")
			.build();

	@Test
	public void testVariables() {
		assertTrue(ADMIN.getUID().equals("test"));
		assertTrue(ADMIN.getName().equals("Desmond"));
	}
	
	@Test
	public void testChange() {
		Admin.Builder builder = ADMIN.toBuilder();
		
		builder.withName("Bob");
		builder.withUID("me");
		
		Admin admin2 = builder.build();
		
		assertTrue(admin2.getName().equals("Bob"));
		assertTrue(admin2.getUID().equals("me"));
	}
}
