package edu.ua.crimson.planr.event.task;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ua.crimson.planr.model.event.task.Task;
import edu.ua.crimson.planr.model.event.user.impl.Admin;
import edu.ua.crimson.planr.model.event.user.impl.Participant;

/**
 * Tests the Task class.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class TaskTest {

	/**
	 * The task variable.
	 */
	private static final Task TASK = Task.Builder.newBuilder()
			.withOwner(Participant.Builder.newBuilder()
					.withName("Desmond")
					.withUID("me")
					.build())
			.withName("task")
			.withDescription("desc")
			.withLimit(10)
			.withCost(500)
			.addAssignee(Admin.Builder.newBuilder()
					.withName("Jake")
					.withUID("322")
					.build())
			.build();

	@Test
	public void testVariables() {
		assertTrue(
				TASK.getOwner().getName().equals("Desmond") &&
				TASK.getOwner().getUID().equals("me") &&
				TASK.getName().equals("task") &&
				TASK.getDescription().equals("desc") &&
				TASK.getLimit() == 10 &&
				TASK.getCost() == 500 &&
				TASK.getAssignees().get(0).getName().equals("Jake") &&
				TASK.getAssignees().get(0).getUID().equals("322")
				);
	}

	@Test
	public void testChange() {
		Task.Builder builder = TASK.toBuilder();

		builder.removeAssignee(TASK.getAssignees().get(0));

		assertTrue(builder.build().getAssignees().size() == 0);

		builder.withOwner(Participant.Builder.newBuilder()
				.withName("bob")
				.withUID("uid")
				.build())
		.withName("lol")
		.withDescription("ha")
		.withLimit(1)
		.withCost(50)
		.addAssignee(Admin.Builder.newBuilder()
				.withName("Ja")
				.withUID("32")
				.build());
		
		Task task = builder.build();
		
		assertTrue(
				task.getOwner().getName().equals("bob") &&
				task.getOwner().getUID().equals("uid") &&
				task.getName().equals("lol") &&
				task.getDescription().equals("ha") &&
				task.getLimit() == 1 &&
				task.getCost() == 50 &&
				task.getAssignees().get(0).getName().equals("Ja") &&
				task.getAssignees().get(0).getUID().equals("32")
				);
	}

}
