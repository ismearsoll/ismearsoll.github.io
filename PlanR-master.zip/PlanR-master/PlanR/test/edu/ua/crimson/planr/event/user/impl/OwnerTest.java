package edu.ua.crimson.planr.event.user.impl;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ua.crimson.planr.model.event.user.impl.Owner;

/**
 * Tests the Owner class.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class OwnerTest {

	/**
	 * The Owner variable.
	 */
	private static final Owner OWNER = Owner.Builder.newBuilder()
			.withUID("test")
			.withName("Desmond")
			.build();

	@Test
	public void testVariables() {
		assertTrue(OWNER.getUID().equals("test"));
		assertTrue(OWNER.getName().equals("Desmond"));
	}
	
	@Test
	public void testChange() {
		Owner.Builder builder = OWNER.toBuilder();
		
		builder.withName("Bob");
		builder.withUID("me");
		
		Owner owner2 = builder.build();
		
		assertTrue(owner2.getName().equals("Bob"));
		assertTrue(owner2.getUID().equals("me"));
	}

}
