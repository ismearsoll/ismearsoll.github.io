package edu.ua.crimson.planr.event.user.impl;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ua.crimson.planr.model.event.user.impl.Participant;

/**
 * Tests the Participant class.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class ParticipantTest {

	/**
	 * The Participant variable.
	 */
	private static final Participant PARTICIPANT = Participant.Builder.newBuilder()
			.withUID("test")
			.withName("Desmond")
			.build();

	@Test
	public void testVariables() {
		assertTrue(PARTICIPANT.getUID().equals("test"));
		assertTrue(PARTICIPANT.getName().equals("Desmond"));
	}
	
	@Test
	public void testChange() {
		Participant.Builder builder = PARTICIPANT.toBuilder();
		
		builder.withName("Bob");
		builder.withUID("me");
		
		Participant participant2 = builder.build();
		
		assertTrue(participant2.getName().equals("Bob"));
		assertTrue(participant2.getUID().equals("me"));
	}

}
