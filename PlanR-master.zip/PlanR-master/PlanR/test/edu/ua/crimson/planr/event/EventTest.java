package edu.ua.crimson.planr.event;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ua.crimson.planr.model.event.Event;
import edu.ua.crimson.planr.model.event.task.Task;
import edu.ua.crimson.planr.model.event.user.impl.Admin;
import edu.ua.crimson.planr.model.event.user.impl.Owner;
import edu.ua.crimson.planr.model.event.user.impl.Participant;

/**
 * Tests the Event class.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class EventTest {
	
	/**
	 * The Owner variable.
	 */
	private static final Owner OWNER = Owner.Builder.newBuilder()
			.withUID("test")
			.withName("Desmond")
			.build();
	
	/**
	 * The admin variable.
	 */
	private static final Admin ADMIN = Admin.Builder.newBuilder()
			.withUID("test")
			.withName("Desmond")
			.build();
	
	/**
	 * The Participant variable.
	 */
	private static final Participant PARTICIPANT = Participant.Builder.newBuilder()
			.withUID("test")
			.withName("Desmond")
			.build();
	
	/**
	 * The task variable.
	 */
	private static final Task TASK = Task.Builder.newBuilder()
			.withOwner(Participant.Builder.newBuilder()
					.withName("Desmond")
					.withUID("me")
					.build())
			.withName("task")
			.withDescription("desc")
			.withLimit(10)
			.withCost(500)
			.addAssignee(Admin.Builder.newBuilder()
					.withName("Jake")
					.withUID("322")
					.build())
			.build();
	
	/**
	 * The event variable.
	 */
	private static final Event EVENT = Event.Builder.newBuilder()
			.withName("PARTY")
			.withOwner(OWNER)
			.addAdmin(ADMIN)
			.addParticipant(PARTICIPANT)
			.addTask(TASK)
			.withDescription("desc")
			.withDate("mm-dd-yyyy")
			.withStatus(true)
			.build();

	@Test
	public void testVariables() {
		assertTrue(
				EVENT.getName().equals("PARTY") &&
				EVENT.getOwner().equals(OWNER) &&
				EVENT.getAdmins().get(0).equals(ADMIN) &&
				EVENT.getParticipants().get(0).equals(PARTICIPANT) &&
				EVENT.getDescription().equals("desc") &&
				EVENT.getDate().equals("mm-dd-yyyy") &&
				EVENT.getStatus()
				);
	}
	
	@Test
	public void testChange() {
		Event.Builder builder = EVENT.toBuilder();
		
		Owner owner = Owner.Builder.newBuilder().withName("tom").build();
		Admin admin = Admin.Builder.newBuilder().withName("bob").build();
		Participant participant = Participant.Builder.newBuilder().withName("par").build();
		Task task = Task.Builder.newBuilder().withCost(200).build();
		
		builder.withName("Paul");
		builder.withOwner(owner);
		builder.addAdmin(admin);
		builder.addParticipant(participant);
		builder.addTask(task);
		builder.withDescription("d");
		builder.withDate("11-11-1111");
		builder.withStatus(false);
		
		Event event = builder.build();
		
		assertTrue(
				event.getName().equals("Paul") &&
				event.getOwner().equals(owner) &&
				event.getAdmins().get(1).equals(admin) &&
				event.getParticipants().get(1).equals(participant) &&
				event.getTasks().get(1).equals(task) &&
				event.getDescription().equals("d") &&
				event.getDate().equals("11-11-1111") &&
				event.getStatus() == false
				);
	}
	
}
