package edu.ua.crimson.planr.server.handler.response;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the Response class.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class ResponseTest {
	
	/**
	 * Success string.
	 */
	private static final String GOOD_STRING = "{\"success\":\"hi\"}";
	
	/**
	 * Error string.
	 */
	private static final String BAD_STRING = "{\"error\":\"e\"}";
	
	@Test
	public void test() {
		assertTrue(GOOD_STRING.equals(Response.Builder.newBuilder().withSuccess("hi").build().getJSON()));
		assertTrue(BAD_STRING.equals(Response.Builder.newBuilder().withError("e").build().getJSON()));
	}

}
