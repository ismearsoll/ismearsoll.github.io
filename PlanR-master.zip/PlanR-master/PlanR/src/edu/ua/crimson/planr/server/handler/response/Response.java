package edu.ua.crimson.planr.server.handler.response;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;

/**
 * Represents a request response.<br><br>
 * 
 * Format of success - {"success":"response"} <br>
 * 
 * Format of error - {"error":"error"}
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class Response {
	
	/**
	 * The JSON objects.
	 */
	private Map<String, Object> jsonObjects;
	
	/**
	 * Creates a new request response representation.
	 * 
	 * @param jsonObjects The JSON objects
	 */
	private Response(Map<String, Object> jsonObjects) {
		this.jsonObjects = jsonObjects;
	}
	
	/**
	 * Converts the JSON objects to a string.
	 * 
	 * @return The converted string
	 */
	public String getJSON() {
		return new Gson().toJson(jsonObjects);
	}
	
	/**
	 * Converts the request response representation into a builder instance.
	 * 
	 * @return The converted builder instance
	 */
	public Builder toBuilder() {
		return new Builder(jsonObjects);
	}
	
	/**
	 * The builder.
	 * 
	 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
	 */
	public static class Builder {
		
		/**
		 * The jsonObjects new value.
		 */
		private Map<String, Object> newJsonObjects;
		
		/**
		 * Creates a new builder instance.
		 */
		private Builder() {
			newJsonObjects = new HashMap<String, Object>();
		}

		/**
		 * Creates a new builder instance.
		 * 
		 * @param jsonObjects The jsonObjects
		 */
		private Builder(Map<String, Object> jsonObjects) {
			newJsonObjects = jsonObjects;
		}
		
		/**
		 * Sets the "error" JSON object.
		 * 
		 * @param object The data
		 * 
		 * @return The builder instance
		 */
		public Builder withError(Object object) {
			newJsonObjects.remove("success");
			newJsonObjects.put("error", object);
			return this;
		}
		
		/**
		 * Sets the "error" JSON object.
		 * 
		 * @param object The data
		 * 
		 * @return The builder instance
		 */
		public Builder withSuccess(Object object) {
			newJsonObjects.remove("error", object);
			newJsonObjects.put("success", object);
			return this;
		}
		
		/**
		 * Builds the request response instance.
		 * 
		 * @return The request response instance
		 */
		public Response build() {
			return new Response(newJsonObjects);
		}
		
		/**
		 * Creates a new builder instance.
		 * 
		 * @return The new builder instance
		 */
		public static Builder newBuilder() {
			return new Builder();
		}
	}

}
