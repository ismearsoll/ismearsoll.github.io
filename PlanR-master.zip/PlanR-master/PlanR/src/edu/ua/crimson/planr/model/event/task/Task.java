package edu.ua.crimson.planr.model.event.task;

import java.util.ArrayList;
import java.util.List;

import edu.ua.crimson.planr.model.event.user.User;
import edu.ua.crimson.planr.model.event.user.impl.Participant;

/**
 * Represents a task.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class Task {
	
	/**
	 * The "owner" field.
	 */
	private User owner;
	
	/**
	 * The "name" field.
	 */
	private String name;
	
	/**
	 * The "description" field.
	 */
	private String description;
	
	/**
	 * The "cost" field.
	 */
	private double cost;
	
	/**
	 * The "assignees" field.
	 */
	private List<User> assignees;
	
	/**
	 * The "limit" field.
	 */
	private int limit;
	
	/**
	 * The "status" field.
	 */
	private boolean status;
	
	/**
	 * Creates a new task representation.
	 * 
	 * @param owner The "owner" field
	 * 
	 * @param name The "name" field
	 * 
	 * @param description The "description" field
	 * 
	 * @param cost The "cost" field
	 * 
	 * @param assignees The "assignees" field
	 * 
	 * @param limit The "limit" field
	 * 
	 * @param status The "status" field
	 */
	private Task(User owner, String name, String description, double cost, List<User> assignees, int limit, boolean status) {
		this.owner = owner;
		this.name = name;
		this.description = description;
		this.cost = cost;
		this.assignees = assignees;
		this.limit = limit;
		this.status = status;
	}
	
	/**
	 * Gets the "status" field's value.
	 * 
	 * @return The "status" field's value
	 */
	public boolean getStatus() {
		return status;
	}
	
	/**
	 * Gets the "limit" field's value.
	 * 
	 * @return The "limit" field's value
	 */
	public int getLimit() {
		return limit;
	}
	
	/**
	 * Gets the "assignees" field's value.
	 * 
	 * @return The "assignees" field's value
	 */
	public List<User> getAssignees() {
		return assignees;
	}
	
	/**
	 * Gets the "cost" field's value.
	 * 
	 * @return The "cost" field's value
	 */
	public double getCost() {
		return cost;
	}
	
	/**
	 * Gets the "description" field's value.
	 * 
	 * @return The "description" field's value
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Gets the "name" field's value.
	 * 
	 * @return The "name" field's value
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Gets the "owner" field's value.
	 * 
	 * @return The "owner" field's value
	 */
	public User getOwner() {
		return owner;
	}
	
	/**
	 * Converts the task representation into a builder instance.
	 * 
	 * @return The converted builder instance
	 */
	public Builder toBuilder() {
		return new Builder(owner, name, description, cost, assignees, limit, status);
	}

	/**
	 * The builder.
	 * 
	 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
	 */
	public static class Builder {
		
		/**
		 * The "owner" field's new value.
		 */
		private User newOwner;
		
		/**
		 * The "name" field's new value.
		 */
		private String newName;
		
		/**
		 * The "description" field's new value.
		 */
		private String newDescription;
		
		/**
		 * The "cost" field's new value.
		 */
		private double newCost;
		
		/**
		 * The "assignees" field's new value.
		 */
		private List<User> newAssignees;
		
		/**
		 * The "limit" field's new value.
		 */
		private int newLimit;
		
		/**
		 * The "status" field's new value.
		 */
		private boolean newStatus;
		
		/**
		 * Creates a new builder instance.
		 */
		private Builder() {
			newOwner = Participant.Builder.newBuilder().build();
			newName = "";
			newDescription = "";
			newCost = 0;
			newAssignees = new ArrayList<User>();
			newLimit = -1;
			newStatus = false;
		}

		/**
		 * Creates a new builder instance.
		 * 
		 * @param owner The "owner" field
		 * 
		 * @param name The "name" field
		 * 
		 * @param description The "description" field
		 * 
		 * @param cost The "cost" field
		 * 
		 * @param assignees The "assignees" field
		 * 
		 * @param limit The "limit" field
		 * 
		 * @param status The "status" field
		 */
		private Builder(User owner, String name, String description, double cost, List<User> assignees, int limit, boolean status) {
			newOwner = owner;
			newName = name;
			newDescription = description;
			newCost = cost;
			newAssignees = assignees;
			newLimit = limit;
			newStatus = status;
		}
		
		/**
		 * Sets the "owner" field's new value.
		 * 
		 * @param owner The "owner" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withOwner(User owner) {
			newOwner = owner;
			return this;
		}
		
		/**
		 * Sets the "name" field's new value.
		 * 
		 * @param name The "name" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withName(String name) {
			newName = name;
			return this;
		}
		
		/**
		 * Sets the "description" field's new value.
		 * 
		 * @param description The "description" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withDescription(String description) {
			newDescription = description;
			return this;
		}
		
		/**
		 * Sets the "cost" field's new value.
		 * 
		 * @param cost The "cost" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withCost(int cost) {
			newCost = cost;
			return this;
		}
		
		/**
		 * Sets the "assignees" field's new value.
		 * 
		 * @param assignees The "assignees" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withAssignees(List<User> assignees) {
			newAssignees = assignees;
			return this;
		}
		
		/**
		 * Adds a user to the "assignees" field.
		 * 
		 * @param user The user
		 * 
		 * @return The builder instance
		 */
		public Builder addAssignee(User user) {
			newAssignees.add(user);
			return this;
		}
		
		/**
		 * Removes a user from the "assignees" field.
		 * 
		 * @param user The user
		 * 
		 * @return The builder instance
		 */
		public Builder removeAssignee(User user) {
			newAssignees.remove(user);
			return this;
		}
		
		/**
		 * Sets the "limit" field's new value.
		 * 
		 * @param limit The "limit" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withLimit(int limit) {
			newLimit = limit;
			return this;
		}
		
		/**
		 * Sets the "status" field's new value.
		 * 
		 * @param status The "status" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withStatus(boolean status) {
			newStatus = status;
			return this;
		}
		
		/**
		 * Builds the task representation instance.
		 * 
		 * @return The task representation instance
		 */
		public Task build() {
			return new Task(newOwner, newName, newDescription, newCost, newAssignees, newLimit, newStatus);
		}
		
		/**
		 * Creates a new builder instance.
		 * 
		 * @return The new builder instance
		 */
		public static Builder newBuilder() {
			return new Builder();
		}
	}
	
}
