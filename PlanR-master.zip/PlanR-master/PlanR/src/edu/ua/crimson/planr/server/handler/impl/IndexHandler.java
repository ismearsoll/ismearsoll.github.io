package edu.ua.crimson.planr.server.handler.impl;

import edu.ua.crimson.planr.server.handler.RequestHandler;
import edu.ua.crimson.planr.server.handler.response.Response;

/**
 * The "/" end-point. <br><br>
 * 
 * Success - {"success":"PlanR WebServer is Running!"}
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class IndexHandler extends RequestHandler {

	@Override
	protected boolean isValidated() {
		return true;
	}

	@Override
	protected String execute() {
		return Response.Builder.newBuilder().withSuccess("PlanR WebServer is Running!").build().getJSON();
	}

}
