package edu.ua.crimson.planr.server;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;

import com.sun.net.httpserver.HttpServer;

import edu.ua.crimson.planr.server.handler.impl.ChargeHandler;
import edu.ua.crimson.planr.server.handler.impl.EventAddHandler;
import edu.ua.crimson.planr.server.handler.impl.EventDeleteHandler;
import edu.ua.crimson.planr.server.handler.impl.EventUpdateHandler;
import edu.ua.crimson.planr.server.handler.impl.EventsHandler;
import edu.ua.crimson.planr.server.handler.impl.IndexHandler;
import edu.ua.crimson.planr.server.handler.impl.LoginHandler;
import edu.ua.crimson.planr.server.handler.impl.RegisterHandler;
import edu.ua.crimson.planr.server.handler.impl.UsersHandler;

/**
 * The web server.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class WebServer {
	
	/**
	 * Starts the web server on the specified port.
	 * 
	 * @param port The port
	 */
	public static void start(int port) {
		try {
			HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
			
			server.setExecutor(Executors.newCachedThreadPool());

			server.createContext("/", new IndexHandler());
			
			server.createContext("/register", new RegisterHandler());
			server.createContext("/login", new LoginHandler());
			
			server.createContext("/users", new UsersHandler());
			
			server.createContext("/event/add", new EventAddHandler());
			server.createContext("/event/delete", new EventDeleteHandler());
			server.createContext("/event/update", new EventUpdateHandler());
			server.createContext("/events", new EventsHandler());
			
			server.createContext("/charge", new ChargeHandler());
			
			server.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
