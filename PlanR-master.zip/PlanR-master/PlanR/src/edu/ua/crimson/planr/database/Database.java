package edu.ua.crimson.planr.database;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.bson.Document;

import com.google.gson.Gson;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import edu.ua.crimson.planr.model.event.Event;
import edu.ua.crimson.planr.model.event.user.User;

/**
 * Represents the database.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class Database {

	/**
	 * The MongoDB host.
	 */
	private static final String MONGODB_HOST = "localhost";

	/**
	 * The MongoDB port.
	 */
	private static final int MONGODB_PORT = 27017;

	/**
	 * The MongoDB client.
	 */
	private static final MongoClient CLIENT = new MongoClient(MONGODB_HOST, MONGODB_PORT);

	/**
	 * The PlanR database.
	 */
	private static final MongoDatabase PLANR_DATABASE = CLIENT.getDatabase("planr");

	/**
	 * The users test collection.
	 */
	private static final MongoCollection<Document> USERS = PLANR_DATABASE.getCollection("users_dev");

	/**
	 * The events test collection.
	 */
	private static final MongoCollection<Document> EVENTS = PLANR_DATABASE.getCollection("events_dev");

	/**
	 * Registers a new user.
	 * 
	 * @param username The username
	 * 
	 * @param password The password
	 * 
	 * @return REGISTRATION_USER_ALREADY_EXISTS if failed
	 */
	public static synchronized DatabaseCode registerNewUser(String username, String password) {
		if (username.isEmpty() || password.isEmpty())
			return DatabaseCode.REGISTRATION_USER_REQUIREMENTS_NOT_MET;

		Document document = getRegisteredUserByName(username);

		if (document == null) {

			BasicDBObject object = new BasicDBObject();

			object.put("uid", UUID.randomUUID().toString());
			object.put("name", username);
			object.put("password", hash(password));

			USERS.insertOne(Document.parse(object.toJson()));

			return DatabaseCode.REGISTRATION_USER_SUCCESSFUL;
		}

		return DatabaseCode.REGISTRATION_USER_ALREADY_EXISTS;
	}

	/**
	 * Attempts to login.
	 * 
	 * @param username The username
	 * 
	 * @param password The password
	 * 
	 * @return LOGIN_INCORRECT if failed
	 */
	public static synchronized DatabaseCode login(String username, String password) {
		Document document = getRegisteredUserByName(username);

		if (document != null && document.getString("password").equals(hash(password)))
			return DatabaseCode.LOGIN_SUCCESSFUL;

		return DatabaseCode.LOGIN_INCORRECT;
	}

	/**
	 * Gets a user uid by name.
	 * 
	 * @param username The username
	 * 
	 * @return The uid
	 */
	public static synchronized String getUserUID(String username) {
		return getRegisteredUserByName(username).getString("uid");
	}

	/**
	 * Gets all the users found in the USERS collection.
	 * 
	 * @return All the users found in the USERS collection
	 */
	public static synchronized User[] getAllUsers() {
		List<User> users = new ArrayList<User>();

		MongoCursor<Document> iterator = USERS.find().iterator();

		while (iterator.hasNext()) {
			Document user = iterator.next();

			users.add(new Gson().fromJson(user.toJson(), User.class));
		}

		return users.toArray(new User[users.size()]);
	}

	/**
	 * Attempts to store an event.
	 * 
	 * @param event The event
	 * 
	 * @return EVENT_CREATE_ALREADY_EXISTS if the event already exists
	 */
	public static synchronized DatabaseCode createEvent(Event event) {
		Document document = getEventByName(event.getName());

		if (document == null) {

			EVENTS.insertOne(Document.parse(new Gson().toJson(event)));

			return DatabaseCode.EVENT_CREATE_SUCCESSFUL;
		}

		return DatabaseCode.EVENT_CREATE_ALREADY_EXISTS;
	}

	/**
	 * Attempts to update an event.
	 * 
	 * @param oldEvent The old event
	 * 
	 * @param newEvent The new event
	 * 
	 * @return EVENT_UPDATE_NOT_FOUND if the event was not found
	 */
	public static synchronized DatabaseCode updateEvent(Event oldEvent, Event newEvent) {
		Document document = getEventByName(oldEvent.getName());

		if (document != null) {

			EVENTS.replaceOne(document, Document.parse(new Gson().toJson(newEvent)));

			return DatabaseCode.EVENT_UPDATE_SUCCESSFUL;
		}

		return DatabaseCode.EVENT_UPDATE_NOT_FOUND;
	}

	/**
	 * Attempts to delete an event.
	 * 
	 * @param event The event
	 * 
	 * @return EVENT_DELETE_NOT_FOUND if the event was not found
	 */
	public static synchronized DatabaseCode deleteEvent(Event event) {
		Document document = getEventByName(event.getName());

		if (document != null) {

			EVENTS.deleteOne(document);

			return DatabaseCode.EVENT_DELETE_SUCCESSFUL;

		}

		return DatabaseCode.EVENT_DELETE_NOT_FOUND;
	}

	/**
	 * Gets an event by name.
	 * 
	 * @param name The event name
	 * 
	 * @return null if the event is not found
	 */
	public static synchronized Event getEvent(String name) {
		Document event = getEventByName(name);

		if (event != null)
			return new Gson().fromJson(event.toJson(), Event.class);

		return null;
	}

	/**
	 * Gets all the events found in the EVENTS collection.
	 * 
	 * @return All the events found in the EVENTS collection
	 */
	public static synchronized Event[] getAllEvents() {
		List<Event> events = new ArrayList<Event>();

		MongoCursor<Document> iterator = EVENTS.find().iterator();

		while (iterator.hasNext()) {
			Document event = iterator.next();

			events.add(new Gson().fromJson(event.toJson(), Event.class));
		}

		return events.toArray(new Event[events.size()]);
	}

	/**
	 * Gets an event by name.
	 * 
	 * @param name The event name
	 * 
	 * @return null if the event was not found
	 */
	private static synchronized Document getEventByName(String name) {
		BasicDBObject search = new BasicDBObject();

		search.put("name", name);

		return EVENTS.find(search).first();
	}

	/**
	 * Gets the registered user by name.
	 * 
	 * @param name The user name
	 * 
	 * @return null if the user was not found
	 */
	private static synchronized Document getRegisteredUserByName(String name) {
		BasicDBObject search = new BasicDBObject();

		search.put("name", name);

		return USERS.find(search).first();
	}

	/**
	 * Hashes a password.
	 * 
	 * @param password The password
	 * 
	 * @return The hashed password
	 */
	private static String hash(String password) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			byte[] digest = md.digest((password + "salt").getBytes());
			BigInteger integer = new BigInteger(1, digest);
			String hash = integer.toString(16);

			while (hash.length() < 32)
				hash = "0" + hash;

			return hash;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return null;
	}
}
