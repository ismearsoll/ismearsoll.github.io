package edu.ua.crimson.planr.server.handler.impl;

import edu.ua.crimson.planr.database.Database;
import edu.ua.crimson.planr.database.DatabaseCode;
import edu.ua.crimson.planr.server.handler.RequestHandler;
import edu.ua.crimson.planr.server.handler.response.Response;

/**
 * The "/register" end-point.<br><br>
 * 
 * POST username<br>
 * POST password<br><br>
 * 
 * Success - {"success":"Account successfully created!"}<br>
 * Error - {"error":"ERROR MESSAGE"}
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class RegisterHandler extends RequestHandler {

	@Override
	protected boolean isValidated() {
		return POST_PARAMETERS.containsKey("username") && POST_PARAMETERS.containsKey("password");
	}

	@Override
	protected String execute() {
		DatabaseCode code = Database.registerNewUser(POST_PARAMETERS.get("username"), POST_PARAMETERS.get("password"));
		
		if (code == DatabaseCode.REGISTRATION_USER_ALREADY_EXISTS)
			return Response.Builder.newBuilder().withError("User already exists!").build().getJSON();
		else if (code == DatabaseCode.REGISTRATION_USER_REQUIREMENTS_NOT_MET)
			return Response.Builder.newBuilder().withError("Missing a username or password!").build().getJSON();
		
		return Response.Builder.newBuilder().withSuccess("Account successfully created!").build().getJSON();
	}

}
