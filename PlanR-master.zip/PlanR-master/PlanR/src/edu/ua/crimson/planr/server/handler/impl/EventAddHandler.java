package edu.ua.crimson.planr.server.handler.impl;

import com.google.gson.Gson;

import edu.ua.crimson.planr.database.Database;
import edu.ua.crimson.planr.database.DatabaseCode;
import edu.ua.crimson.planr.model.event.Event;
import edu.ua.crimson.planr.server.handler.RequestHandler;
import edu.ua.crimson.planr.server.handler.response.Response;

/**
 * The "/event/add" end-point.<br><br>
 * 
 * POST event<br><br>
 * 
 * Success - {"success":"Event successfully added!"}<br>
 * Error - {"error":"This event name already exists!"}
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class EventAddHandler extends RequestHandler {

	@Override
	protected boolean isValidated() {
		return POST_PARAMETERS.containsKey("event");
	}

	@Override
	protected String execute() {
		DatabaseCode code = Database.createEvent(new Gson().fromJson(POST_PARAMETERS.get("event"), Event.class));
		
		if (code == DatabaseCode.EVENT_CREATE_ALREADY_EXISTS)
			return Response.Builder.newBuilder().withError("This event name already exists!").build().getJSON();
		
		return Response.Builder.newBuilder().withSuccess("Event successfully added!").build().getJSON();
	}

}
