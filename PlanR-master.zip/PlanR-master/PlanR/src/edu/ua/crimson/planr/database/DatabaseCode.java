package edu.ua.crimson.planr.database;

/**
 * The Database response codes.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public enum DatabaseCode {
	
	/**
	 * User requirements not met; missing a username, a password, or both.
	 */
	REGISTRATION_USER_REQUIREMENTS_NOT_MET,
	
	/**
	 * User already exists in the database.
	 */
	REGISTRATION_USER_ALREADY_EXISTS,
	
	/**
	 * User registration was successful.
	 */
	REGISTRATION_USER_SUCCESSFUL,
	
	/**
	 * Login incorrect.
	 */
	LOGIN_INCORRECT,
	
	/**
	 * Login successful.
	 */
	LOGIN_SUCCESSFUL,
	
	/**
	 * Event already exists.
	 */
	EVENT_CREATE_ALREADY_EXISTS,
	
	/**
	 * Event creation successful.
	 */
	EVENT_CREATE_SUCCESSFUL,
	
	/**
	 * Event does not exist.
	 */
	EVENT_UPDATE_NOT_FOUND,
	
	/**
	 * Event update successful.
	 */
	EVENT_UPDATE_SUCCESSFUL,
	
	/**
	 * Event does not exist.
	 */
	EVENT_DELETE_NOT_FOUND,
	
	/**
	 * Event delete successful.
	 */
	EVENT_DELETE_SUCCESSFUL
}
