package edu.ua.crimson.planr.model.event.user.impl;

import edu.ua.crimson.planr.model.event.user.User;

/**
 * Represents an event owner.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class Owner extends User {

	/**
	 * Creates a new event owner representation.
	 * 
	 * @param uid The "uid" field
	 * 
	 * @param name The The "name" field
	 */
	private Owner(String uid, String name) {
		super(uid, name);
	}
	
	/**
	 * Converts the owner instance to a new builder instance.
	 * 
	 * @return The converted builder instance
	 */
	public Builder toBuilder() {
		return new Builder(getUID(), getName());
	}
	
	/**
	 * The builder.
	 * 
	 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
	 */
	public static class Builder {
		
		/**
		 * The "uid" field's new value.
		 */
		private String newUID;
		
		/**
		 * The "name" field's new value
		 */
		private String newName;
		
		/**
		 * Creates a new builder instance.
		 */
		private Builder() {
			newUID = "";
			newName = "";
		}
		
		/**
		 * Sets the "uid" field's new value.
		 * 
		 * @param uid The "uid" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withUID(String uid) {
			newUID = uid;
			return this;
		}
		
		/**
		 * Sets the "name" field's new value.
		 * 
		 * @param name The "name" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withName(String name) {
			newName = name;
			return this;
		}
		
		/**
		 * Creates a new builder instance.
		 * 
		 * @param uid The "uid" field
		 * 
		 * @param name The "name" field
		 */
		private Builder(String uid, String name) {
			newUID = uid;
			newName = name;
		}
		
		/**
		 * Builds the event owner representation.
		 * 
		 * @return The event owner representation
		 */
		public Owner build() {
			return new Owner(newUID, newName);
		}
		
		/**
		 * Creates a new builder instance.
		 * 
		 * @return The builder instance
		 */
		public static Builder newBuilder() {
			return new Builder();
		}
	}

}
