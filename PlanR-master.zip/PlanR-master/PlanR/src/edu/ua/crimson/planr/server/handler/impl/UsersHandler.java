package edu.ua.crimson.planr.server.handler.impl;

import edu.ua.crimson.planr.database.Database;
import edu.ua.crimson.planr.server.handler.RequestHandler;
import edu.ua.crimson.planr.server.handler.response.Response;

/**
 * The "/users" end-point.<br><br>
 * 
 * Success - {"success":"A LIST OF ALL USERS IN THE DATABASE"}
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class UsersHandler extends RequestHandler {

	@Override
	protected boolean isValidated() {
		return true;
	}

	@Override
	protected String execute() {
		return Response.Builder.newBuilder().withSuccess(Database.getAllUsers()).build().getJSON();
	}

}
