package edu.ua.crimson.planr.server.handler.impl;

import com.google.gson.Gson;

import edu.ua.crimson.planr.database.Database;
import edu.ua.crimson.planr.database.DatabaseCode;
import edu.ua.crimson.planr.model.event.Event;
import edu.ua.crimson.planr.server.handler.RequestHandler;
import edu.ua.crimson.planr.server.handler.response.Response;

/**
 * The "/event/update" end-point.<br><br>
 * 
 * POST name<br>
 * POST event<br><br>
 * 
 * Success - {"success":"Event successfully updated!"}<br>
 * Error - {"error":"error"}
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class EventUpdateHandler extends RequestHandler {

	@Override
	protected boolean isValidated() {
		return POST_PARAMETERS.containsKey("name") &&
				POST_PARAMETERS.containsKey("event");
	}

	@Override
	protected String execute() {
		DatabaseCode code = Database.updateEvent(Event.Builder.newBuilder().withName(POST_PARAMETERS.get("name")).build(), new Gson().fromJson(POST_PARAMETERS.get("event"), Event.class));
		
		//TODO Security for Event Updating
		
		if (code == DatabaseCode.EVENT_UPDATE_NOT_FOUND)
			return Response.Builder.newBuilder().withError("Event name not found!").build().getJSON();
		
		return Response.Builder.newBuilder().withSuccess("Event successfully updated!").build().getJSON();
	}

}
