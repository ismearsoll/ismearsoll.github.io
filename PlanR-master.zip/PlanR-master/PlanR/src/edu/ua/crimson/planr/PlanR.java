package edu.ua.crimson.planr;

import edu.ua.crimson.planr.server.WebServer;

/**
 * The PlanR app server.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class PlanR {
	
	/**
	 * The main method.
	 * 
	 * @param args String arguments
	 */
	public static void main(String[] args) {
		WebServer.start(30000);
	}

}
