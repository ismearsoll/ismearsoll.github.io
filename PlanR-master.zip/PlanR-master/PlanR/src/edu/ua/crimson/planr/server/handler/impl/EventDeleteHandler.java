package edu.ua.crimson.planr.server.handler.impl;

import edu.ua.crimson.planr.database.Database;
import edu.ua.crimson.planr.database.DatabaseCode;
import edu.ua.crimson.planr.model.event.Event;
import edu.ua.crimson.planr.server.handler.RequestHandler;
import edu.ua.crimson.planr.server.handler.response.Response;

/**
 * The "/event/delete" end-point.<br><br>
 * 
 * POST uid<br>
 * POST name<br><br>
 * 
 * Success - {"success":"Event successfully deleted!"}<br>
 * Error - {"error":"error"}
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class EventDeleteHandler extends RequestHandler {

	@Override
	protected boolean isValidated() {
		return POST_PARAMETERS.containsKey("uid") && POST_PARAMETERS.containsKey("name");
	}

	@Override
	protected String execute() {
		Event event = Database.getEvent(POST_PARAMETERS.get("name"));
		
		if (!event.getOwner().getUID().equals(POST_PARAMETERS.get("uid")))
			return Response.Builder.newBuilder().withError("You are not the owner of the event!").build().getJSON();
		
		DatabaseCode code = Database.deleteEvent(Event.Builder.newBuilder().withName(POST_PARAMETERS.get("name")).build());
		
		if (code == DatabaseCode.EVENT_DELETE_NOT_FOUND)
			return Response.Builder.newBuilder().withError("This event name does not exist!").build().getJSON();
		
		return Response.Builder.newBuilder().withSuccess("Event successfully deleted!").build().getJSON();
	}

}
