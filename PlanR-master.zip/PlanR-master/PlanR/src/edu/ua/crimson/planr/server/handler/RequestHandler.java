package edu.ua.crimson.planr.server.handler;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import edu.ua.crimson.planr.server.handler.response.Response;

/**
 * Handles requests sent to the web server.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public abstract class RequestHandler implements HttpHandler {

	/**
	 * The http exchange.
	 */
	private HttpExchange exchange;

	/**
	 * The GET parameters sent to the web server.
	 */
	protected Map<String, String> GET_PARAMETERS;

	/**
	 * The POST parameters sent to the web server.
	 */
	protected Map<String, String> POST_PARAMETERS;

	/**
	 * Writes a response back to the client.
	 * 
	 * @param response The response
	 */
	private void writeResponse(String response) {
		try {
			exchange.sendResponseHeaders(200, response.length());
			exchange.getResponseBody().write(response.getBytes());
			exchange.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Validates a request.
	 * 
	 * @return true if the request has been validated
	 */
	protected abstract boolean isValidated();

	/**
	 * Called when a request is received and validated.
	 * 
	 * @return The response to write back to the requester
	 */
	protected abstract String execute();

	@Override
	public void handle(HttpExchange exchange) throws IOException {
		this.exchange = exchange;
		GET_PARAMETERS = new HashMap<String, String>();
		POST_PARAMETERS = new HashMap<String, String>();
		
		String query = exchange.getRequestURI().getQuery();

		if (query != null) {
			
			for (String pair : query.split("&")) {
				String[] data = pair.split("=");
				
				GET_PARAMETERS.put(data[0], data[1]);
			}
		}
		
		if (exchange.getRequestMethod().equalsIgnoreCase("post")) {
			StringBuilder sb = new StringBuilder();
			byte[] buffer = new byte[1024];
			int count = 0;
			InputStream in = exchange.getRequestBody();
			
			while ((count = in.read(buffer)) != -1)
				sb.append(new String(buffer, 0, count));
			
			for (String pair : sb.toString().split("&")) {
				String[] data = pair.split("=");
				
				POST_PARAMETERS.put(data[0], data[1]);
				
			}
			
			in.close();
		}

		if (isValidated())
			writeResponse(execute());
		else
			writeResponse(Response.Builder.newBuilder().withError("Missing parameters...").build().getJSON());
	}

}
