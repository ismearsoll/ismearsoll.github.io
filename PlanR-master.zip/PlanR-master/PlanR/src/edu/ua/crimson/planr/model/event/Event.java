package edu.ua.crimson.planr.model.event;

import java.util.ArrayList;
import java.util.List;

import edu.ua.crimson.planr.model.event.task.Task;
import edu.ua.crimson.planr.model.event.user.impl.Admin;
import edu.ua.crimson.planr.model.event.user.impl.Owner;
import edu.ua.crimson.planr.model.event.user.impl.Participant;

/**
 * Represents an event.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class Event {
	
	/**
	 * The "name" field.
	 */
	private String name;
	
	/**
	 * The "owner" field.
	 */
	private Owner owner;
	
	/**
	 * The "admins" field.
	 */
	private List<Admin> admins;
	
	/**
	 * The "participants" field.
	 */
	private List<Participant> participants;
	
	/**
	 * The "tasks" field.
	 */
	private List<Task> tasks;
	
	/**
	 * The "description" field.
	 */
	private String description;
	
	/**
	 * The "date" field.
	 */
	private String date;
	
	/**
	 * The "status" field.
	 */
	private boolean status;
	
	/**
	 * Creates a new event representation.
	 * 
	 * @param name The "name" field
	 * 
	 * @param owner The "owner" field
	 * 
	 * @param admins The "admins" field
	 * 
	 * @param participants The "participants" field
	 * 
	 * @param tasks The "tasks" field
	 * 
	 * @param description The "description" field
	 * 
	 * @param date The "date" field
	 * 
	 * @param status The "status" field
	 */
	private Event(String name, Owner owner, List<Admin> admins, List<Participant> participants, List<Task> tasks, String description, String date, boolean status) {
		this.name = name;
		this.owner = owner;
		this.admins = admins;
		this.participants = participants;
		this.tasks = tasks;
		this.description = description;
		this.date = date;
		this.status = status;
	}
	
	/**
	 * Gets the "status" field's value.
	 * 
	 * @return The "status" field's value
	 */
	public boolean getStatus() {
		return status;
	}
	
	/**
	 * Gets the "date" field's value.
	 * 
	 * @return The "date" field's value
	 */
	public String getDate() {
		return date;
	}
	
	/**
	 * Gets the "description" field's value.
	 * 
	 * @return The "description" field's value
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Gets the "tasks" field's value.
	 * 
	 * @return The "tasks" field's value
	 */
	public List<Task> getTasks() {
		return tasks;
	}
	
	/**
	 * Gets the "admins" field's value.
	 * 
	 * @return The "admins" field's value
	 */
	public List<Admin> getAdmins() {
		return admins;
	}
	
	/**
	 * Gets the "participants" field's value.
	 * 
	 * @return The "participants" field's value
	 */
	public List<Participant> getParticipants() {
		return participants;
	}
	
	/**
	 * Gets the "owner" field's value.
	 * 
	 * @return The "owner" field's value
	 */
	public Owner getOwner() {
		return owner;
	}
	
	/**
	 * Gets the "name" field's value.
	 * 
	 * @return The "name" field's value
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Converts the event representation into a builder instance.
	 * 
	 * @return The converted builder instance
	 */
	public Builder toBuilder() {
		return new Builder(name, owner, admins, participants, tasks, description, date, status);
	}
	
	/**
	 * The builder.
	 * 
	 * @author Desmond Jackson (dajackson4@crimson.ua.edu);
	 */
	public static class Builder {
		
		/**
		 * The "name" field's new value.
		 */
		private String newName;
		
		/**
		 * The "owner" field's new value.
		 */
		private Owner newOwner;
		
		/**
		 * The "admins" field's new value.
		 */
		private List<Admin> newAdmins;
		
		/**
		 * The "participants" field's new value.
		 */
		private List<Participant> newParticipants;
		
		/**
		 * The "tasks" field's new value.
		 */
		private List<Task> newTasks;
		
		/**
		 * The "description" field's new value.
		 */
		private String newDescription;
		
		/**
		 * The "date" field's new value.
		 */
		private String newDate;
		
		/**
		 * The "status" field's new value.
		 */
		private boolean newStatus;
		
		/**
		 * Creates a new builder instance.
		 */
		private Builder() {
			newName = "";
			newOwner = Owner.Builder.newBuilder().build();
			newAdmins = new ArrayList<Admin>();
			newParticipants = new ArrayList<Participant>();
			newTasks = new ArrayList<Task>();
			newDescription = "";
			newDate = "mm-dd-yyyy";
			newStatus = false;
		}
		
		/**
		 * Creates a new builder instance.
		 * 
		 * @param name The "name" field
		 * 
		 * @param owner The "owner" field
		 * 
		 * @param admins The "admins" field
		 * 
		 * @param participants The "participants" field
		 * 
		 * @param tasks The "tasks" field
		 * 
		 * @param description The "description" field
		 * 
		 * @param date The "date" field
		 * 
		 * @param status The "status" field
		 */
		private Builder(String name, Owner owner, List<Admin> admins, List<Participant> participants, List<Task> tasks, String description, String date, boolean status) {
			newName = name;
			newOwner = owner;
			newAdmins = admins;
			newParticipants = participants;
			newTasks = tasks;
			newDescription = description;
			newDate = date;
			newStatus = status;
		}
		
		/**
		 * Sets the "name" field's new value.
		 * 
		 * @param name The "name" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withName(String name) {
			newName = name;
			return this;
		}
		
		/**
		 * Sets the "owner" field's new value.
		 * 
		 * @param owner The "owner" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withOwner(Owner owner) {
			newOwner = owner;
			return this;
		}
		
		/**
		 * Sets the "admins" field's new value.
		 * 
		 * @param admins The "admins" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withAdmins(List<Admin> admins) {
			newAdmins = admins;
			return this;
		}
		
		/**
		 * Adds an admin to the "admins" field
		 * 
		 * @param admin The admin
		 * 
		 * @return The builder instance
		 */
		public Builder addAdmin(Admin admin) {
			newAdmins.add(admin);
			return this;
		}
		
		/**
		 * Removes an admin from the "admins" field
		 * 
		 * @param admin The admin
		 * 
		 * @return The builder instance
		 */
		public Builder removeAdmin(Admin admin) {
			newAdmins.remove(admin);
			return this;
		}
		
		/**
		 * Sets the "participants" field's new value.
		 * 
		 * @param participants The "participants" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withParticipants(List<Participant> participants) {
			newParticipants = participants;
			return this;
		}
		
		/**
		 * Adds a participant to the "participants" field
		 * 
		 * @param participant The participant
		 * 
		 * @return The builder instance
		 */
		public Builder addParticipant(Participant participant) {
			newParticipants.add(participant);
			return this;
		}
		
		/**
		 * Removes a participant from the "participants" field.
		 * 
		 * @param participant The participant
		 * 
		 * @return The builder instance
		 */
		public Builder removeParticipant(Participant participant) {
			newParticipants.remove(participant);
			return this;
		}
		
		/**
		 * Sets the "tasks" field's new value.
		 * 
		 * @param tasks The "tasks" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withTasks(List<Task> tasks) {
			newTasks = tasks;
			return this;
		}
		
		/**
		 * Adds a task to the "tasks" field.
		 * 
		 * @param task The task
		 * 
		 * @return The builder instance
		 */
		public Builder addTask(Task task) {
			newTasks.add(task);
			return this;
		}
		
		/**
		 * Removes a task from the "tasks" field.
		 * 
		 * @param task The task
		 * 
		 * @return The builder instance
		 */
		public Builder removeTask(Task task) {
			newTasks.remove(task);
			return this;
		}
		
		/**
		 * Sets the "description" field's new value.
		 * 
		 * @param description The description
		 * 
		 * @return The builder instance
		 */
		public Builder withDescription(String description) {
			newDescription = description;
			return this;
		}

		/**
		 * Sets the "date" field's new value.
		 * 
		 * @param date The date
		 * 
		 * @return The builder instance
		 */
		public Builder withDate(String date) {
			newDate = date;
			return this;
		}
		
		/**
		 * Sets the "status" field's new value.
		 * 
		 * @param status The status
		 * 
		 * @return The builder instance
		 */
		public Builder withStatus(boolean status) {
			newStatus = status;
			return this;
		}
		
		/**
		 * Builds the event representation instance.
		 * 
		 * @return The event representation instance
		 */
		public Event build() {
			return new Event(newName, newOwner, newAdmins, newParticipants, newTasks, newDescription, newDate, newStatus);
		}
		
		/**
		 * Creates a new builder instance.
		 * 
		 * @return The builder instance
		 */
		public static Builder newBuilder() {
			return new Builder();
		}
	}

}
