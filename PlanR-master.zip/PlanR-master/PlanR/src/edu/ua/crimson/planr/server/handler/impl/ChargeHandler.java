package edu.ua.crimson.planr.server.handler.impl;

import java.math.BigDecimal;

import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.Environment;
import com.braintreegateway.TransactionRequest;

import edu.ua.crimson.planr.database.Database;
import edu.ua.crimson.planr.model.event.Event;
import edu.ua.crimson.planr.model.event.task.Task;
import edu.ua.crimson.planr.server.handler.RequestHandler;
import edu.ua.crimson.planr.server.handler.response.Response;

/**
 * Charges events.
 * 
 * @author Jake Wachs
 *
 */
public class ChargeHandler extends RequestHandler {
	/* Initiate API gateway */
	BraintreeGateway gateway = new BraintreeGateway(
			Environment.SANDBOX,
			"w8m3z9bhk54bsc6y",
			"wt2342z2ntm79cfy",
			"cc93295190d8bb0e3f3681235fedf1a3");		// free sandbox credentials

	@Override
	protected boolean isValidated() {
		return POST_PARAMETERS.containsKey("name");
	}

	@Override
	protected String execute() {
		Event event = Database.getEvent(POST_PARAMETERS.get("name"));

		if (event == null)
			return Response.Builder.newBuilder().withError("Event does not exist").build().getJSON();

		boolean complete = true;

		for (Task task : event.getTasks())
			if (task.getStatus() == false) {
				complete = false;
				break;
			}

		if (complete == false)
			return Response.Builder.newBuilder().withError("All tasks were not complete.").build().getJSON();

		for (Task task : event.getTasks()) {
			System.out.println(task.getName());
			double cost = task.getCost();
			int participants = task.getAssignees().size();

			for (int i = 0; i < participants; i++) {

				double toCharge = cost / participants;
				String amt = Double.toString(toCharge);

				/* Create new transaction request to be sent to BrainTree server */
				TransactionRequest request = new TransactionRequest()
						.amount(new BigDecimal(amt))
						.paymentMethodNonce("fake-venmo-account-nonce")
						.options()
						.submitForSettlement(true)
						.done();

				/* Actually conduct the transaction */
				gateway.transaction().sale(request).getTarget();
			}

		}

		return Response.Builder.newBuilder().withSuccess("All chargers were completed.").build().getJSON();
	}

}
