package edu.ua.crimson.planr.model.event.user;

/**
 * Represents a user.
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class User {
	
	/**
	 * The "uid" field.
	 */
	private String uid;
	
	/**
	 * The "name" field.
	 */
	private String name;
	
	/**
	 * Creates a new user representation.
	 * 
	 * @param uid The "uid" field
	 * 
	 * @param name The The "name" field
	 */
	protected User(String uid, String name) {
		this.uid = uid;
		this.name = name;
	}
	
	/**
	 * Gets the "name" field's value.
	 * 
	 * @return The "name" field's value
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Gets the "uid" field's value.
	 * 
	 * @return The "uid" field's value
	 */
	public String getUID() {
		return uid;
	}
	
	/**
	 * The builder.
	 * 
	 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
	 */
	public static class Builder {
		
		/**
		 * The "uid" field's new value.
		 */
		private String newUID;
		
		/**
		 * The "name" field's new value
		 */
		private String newName;
		
		/**
		 * Creates a new builder instance.
		 */
		private Builder() {
			newUID = "";
			newName = "";
		}
		
		/**
		 * Creates a new builder instance.
		 * 
		 * @param uid The "uid" field
		 * 
		 * @param name The "name" field
		 */
		private Builder(String uid, String name) {
			newUID = uid;
			newName = name;
		}
		
		/**
		 * Sets the "uid" field's new value.
		 * 
		 * @param uid The "uid" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withUID(String uid) {
			newUID = uid;
			return this;
		}
		
		/**
		 * Sets the "name" field's new value.
		 * 
		 * @param name The "name" field's new value
		 * 
		 * @return The builder instance
		 */
		public Builder withName(String name) {
			newName = name;
			return this;
		}
		
		/**
		 * Builds the event owner representation.
		 * 
		 * @return The event owner representation
		 */
		public User build() {
			return new User(newUID, newName);
		}
		
		/**
		 * Creates a new builder instance.
		 * 
		 * @return The builder instance
		 */
		public static Builder newBuilder() {
			return new Builder();
		}
	}

}
