package edu.ua.crimson.planr.server.handler.impl;

import edu.ua.crimson.planr.server.handler.RequestHandler;
import edu.ua.crimson.planr.server.handler.response.Response;
import edu.ua.crimson.planr.database.Database;
import edu.ua.crimson.planr.database.DatabaseCode;

/**
 * The "/login" end-point.<br><br>
 * 
 * POST username<br>
 * POST password<br><br>
 * 
 * Success - {"success":"UID"}<br>
 * Error - {"error":"ERROR MESSAGE"}
 * 
 * @author Desmond Jackson (dajackson4@crimson.ua.edu)
 */
public class LoginHandler extends RequestHandler {

	@Override
	protected boolean isValidated() {
		return POST_PARAMETERS.containsKey("username") && POST_PARAMETERS.containsKey("password");
	}

	@Override
	protected String execute() {
		DatabaseCode code = Database.login(POST_PARAMETERS.get("username"), POST_PARAMETERS.get("password"));
		
		if (code == DatabaseCode.LOGIN_INCORRECT)
			return Response.Builder.newBuilder().withError("Invalid username or password").build().getJSON();
		
		return Response.Builder.newBuilder().withSuccess(Database.getUserUID(POST_PARAMETERS.get("username"))).build().getJSON();
	}

}
