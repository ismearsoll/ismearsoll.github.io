import React from 'react';
import { Alert, StyleSheet, Button, TextInput, KeyboardAvoidingView } from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import homeScreen from './src/homeScreen.js'
import accountScreen from './src/accountScreen.js'
import CustomLoginPage from './src/loginScreen.js'
import registrationPage from './src/registrationScreen.js';
import EventScreen from './src/eventPage.js';
import NewEventPage from './src/newEventPage.js';
import NewTaskPage from './src/newTaskPage.js';
import EventParticipantsPage from './src/eventParticipantsPage.js';
import TaskPage from './src/taskPage.js';
import EditEventPage from './src/editEventPage.js';
import EditTaskPage from './src/editTaskPage.js';




let test = true;

//Navigator page begin

const AppNavigator = createStackNavigator(
{
  startup: CustomLoginPage,
  registrationPage: registrationPage,
  homePage: homeScreen,
  accountScreen: accountScreen,
  eventScreen: EventScreen,
  newEventScreen: NewEventPage,
  newTaskScreen: NewTaskPage,
  eventParticipants: EventParticipantsPage,
  taskScreen: TaskPage,
  editEventScreen: EditEventPage,
  editTaskScreen: EditTaskPage,
},
{
  initialRouteName: 'startup',

  defaultNavigationOptions: {
    headerStyle: {
      backgroundColor: '#007DE9',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  },
}
);

const AppContainer = createAppContainer(AppNavigator);

export default class App extends React.Component {
  render() {
    return <AppContainer />;
  }
}


