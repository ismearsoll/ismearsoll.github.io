import React from 'react';
import 'react-native';
import EventSummary from '../src/eventSummary';
import { render, fireEvent } from 'react-native-testing-library';
import 'isomorphic-fetch';
import renderer from 'react-test-renderer';

import jsonArrInit from '../assets/jsonDEV.json';

//Test that the event summary page renders
it('renders correctly', () => {
  const tree = renderer.create(<EventSummary event={jsonArrInit.success[0]}/>).toJSON();
  expect(tree).toMatchSnapshot();
});