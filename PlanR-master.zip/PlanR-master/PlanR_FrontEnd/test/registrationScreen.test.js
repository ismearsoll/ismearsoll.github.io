import React from 'react';
import 'react-native';
import RegistrationPage from '../src/registrationScreen';
import { render, fireEvent } from 'react-native-testing-library';
import 'isomorphic-fetch';
import renderer from 'react-test-renderer';

//Test that the registration page renders
it('renders correctly', () => {
  const tree = renderer.create(<RegistrationPage/>).toJSON();
  expect(tree).toMatchSnapshot();
});

//Test that the page handles mismatching passwords
it('handles password mismatch', () => {
  const passErrMsg = 'Passwords do not match';
  const { getByTestId, getByPlaceholder } = render(
    <RegistrationPage/>
  );

  const pass = getByPlaceholder('Password');
  fireEvent.changeText(pass, 'aPassword');

  const passConf = getByPlaceholder('Confirm Password');
  fireEvent.changeText(passConf, 'bPassword');
  
  fireEvent.press(getByTestId('button'));
  expect(getByTestId('passwordError').props.children).toBe(passErrMsg);
});

//Test that the page handles good input
it('handles good input', () => {
  const lockedPass = 'password';
  const { getByTestId, getByPlaceholder } = render(
    <RegistrationPage/>
  );

  const user = getByPlaceholder('Username');
  fireEvent.changeText(user, 'username');

  const pass = getByPlaceholder('Password');
  fireEvent.changeText(pass, lockedPass);

  const passConf = getByPlaceholder('Confirm Password');
  fireEvent.changeText(passConf, lockedPass);
  
  fireEvent.press(getByTestId('button'));
  expect(getByTestId('passwordError').props.children).toBe('');
});