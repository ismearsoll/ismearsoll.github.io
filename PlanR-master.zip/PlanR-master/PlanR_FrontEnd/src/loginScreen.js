import React from 'react';
import { Alert, StyleSheet, Button, Text, TextInput, KeyboardAvoidingView } from 'react-native';

import config from './config';

class CustomLoginPage extends React.Component{

    static navigationOptions = {
      title: 'Login Page',
      };
    constructor(props)
    {
      super(props);
  
      this.state = {
        username: '',
        password: '',
        loginErr: ''
      };
    }
  
    onLoginPress()
    {
      let user = this.state.username;
      let pass = this.state.password;
      if(config.mode === 'prod'){
        fetch(`${config.baseURL}/login`, {
          method: 'post',
          headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
          },
          body: `username=${user}&password=${pass}`
        })
        .then(response => response.json())
        .then(responseJson => {
          console.log(responseJson);
          if(responseJson.success){
            this.props.navigation.navigate('homePage', {
              username: user,
              uid: responseJson.success
            });
          }else{
            this.setState({loginErr: responseJson.error});
          }
        })
        .catch((error) => {
          console.log(error.message);
          this.setState({loginErr: error.message});
        });
      }else{
        this.props.navigation.navigate('homePage', {
          username: this.state.username,
          uid: '123abc'
        });
      }
    }

    onRegisterPress()
    {
      this.props.navigation.navigate('registrationPage');
    }
  
    render()
    {
      return(
        <KeyboardAvoidingView style = {styles.Container} behavior = "padding">
          <TextInput 
              placeholder={'Username'}
              value={this.state.username}
              onChangeText={username => this.setState({ username })}
              style={styles.loginInput}
              autoCapitalize= 'none'
              >    
            </TextInput>
            <TextInput placeholder={'Password'}
              value={this.state.password}
              onChangeText={password => this.setState({ password })}
              style={styles.loginInput}
              secureTextEntry={true}
              >
            </TextInput>
            <Button title="Login"
                onPress={this.onLoginPress.bind(this)}
                style={styles.loginButton}
              >
            </Button>
            <Button title="Register"
                onPress={this.onRegisterPress.bind(this)}
                style={styles.loginButton}
              >
            </Button>
            <Text style={{color: 'red'}}>{this.state.loginErr}</Text>
        </KeyboardAvoidingView>
      )
    }
  }
  
  const styles = StyleSheet.create({
    Container: {
      backgroundColor: '#fff',
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
    },
    loginInput: {
      borderColor: 'black',
      borderWidth: 1,
      marginBottom: 10,
      width: "50%",
      height: 40,
      padding: 10,
    },
    loginButton:
    {
      padding: 10,
      backgroundColor: '#007DE9',
      marginBottom: 10,
    }
  });
  

  export default CustomLoginPage;