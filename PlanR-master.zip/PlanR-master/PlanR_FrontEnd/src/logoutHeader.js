import React from 'react';
import { StyleSheet, Text, View, Button, TouchableHighlight, Image} from 'react-native';

class LogoutHeader extends React.Component{
  render()
  {
  return(
    <View style={styles.Container}>
      <View style={styles.textViewStyle}>
        <Text style={styles.textStyle} color="#fff">
          {this.props.title} 
        </Text>
      </View>
      <TouchableHighlight
        onPress={() => this.props.navigation.navigate('startup')}
        >
        <Image
          source={require('../assets/MenuIcon.png')}
          style={styles.imageStyle}>
        </Image>
      </TouchableHighlight>
    </View>
  )
  }
}

const styles = StyleSheet.create({
  Container: {
    backgroundColor: '#007DE9',
    padding: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    flex: 1
  },
  imageStyle: {
    width: 30, 
    height: 30,
    borderWidth: 1,
    borderColor: 'white',
    backgroundColor: 'white',
  },
  textStyle: {
    fontWeight: 'bold',
    color: "white",
    fontSize: 20,
  },
  textViewStyle:{
    backgroundColor: "#007DE9"
  },
});

export default LogoutHeader;
