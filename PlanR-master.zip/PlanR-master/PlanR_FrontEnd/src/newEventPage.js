import React from 'react';
import { Text, Alert, View, StyleSheet, Button, TextInput, KeyboardAvoidingView } from 'react-native';
import DatePicker from 'react-native-datepicker';

import config from './config';

class NewEventPage extends React.Component{

    static navigationOptions = {
      title: 'Create New Event',
      };
    constructor(props)
    {
      super(props);
  
      this.state = {
        eventName: '',
        date: '',
        eventDescription: '',
        time: '',
        submitErr: false,
        eventNameEmpty: 'black',   
        eventDescEmpty: 'black',
        eventTimeEmpty: 'black',     
      };
    }
    componentDidMount()
    {
      var date = new Date().getDate(); //Current Date
      var month = new Date().getMonth() + 1; //Current Month
      var year = new Date().getFullYear(); //Current Year
      this.setState({
        date:
          date + '-' + month + '-' + year,
      });
      this.currentDate = date + '-' + month + '-' + year;
    }
    
    onSubmitPress()
    {
      console.log('In submit');
      if(this.state.eventName != '' && this.state.date !='' && this.state.eventDescription!= '' && this.state.time != '')
      {
        this.setState({
          submitErr: false,
          eventNameEmpty: 'black',
          eventDescEmpty: 'black',
          eventTimeEmpty: 'black'
        });

        const username = this.props.navigation.getParam('username');
        const uid = this.props.navigation.getParam('uid');

        var stringNewEventJSON = `{
          "name": "` + this.state.eventName + `",
          "owner": {
            "uid": "` + uid + `",
            "name": "` + username + `"
          },
          "admins": [
            {
              "uid": "` + uid + `",
              "name": "` + username + `"
            }
          ],
          "participants": [
            {
              "uid": "` + uid + `",
              "name": "` + username + `"
            }
          ],
          "tasks": [],
          "description": "` + this.state.eventDescription + `",
          "status" : false,
          "date" : "` + this.state.date + `",
          "time" : "` + this.state.time + `"}`;

          if(config.mode === 'dev' && !this.state.submitErr){
            Alert.alert(stringNewEventJSON);
            var prevJSON = this.props.navigation.getParam('eventArray');
            prevJSON.push(JSON.parse(stringNewEventJSON));
          }else if(!this.state.submitErr){
            console.log(stringNewEventJSON);
            fetch(`${config.baseURL}/event/add`, {
              method: 'post',
              headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
              },
              body: `event=${stringNewEventJSON}`
            })
            .then(response => response.json())
            .then(responseJson => {
              console.log(responseJson);
            })
            .catch((error) => {
              console.log(error.message);
              this.setState({loginErr: error.message});
            });
          }
          return;
      }

      if(this.state.eventName == '')
      {
        this.setState({
          submitErr: true,
          eventNameEmpty: 'red',
        });
      }else{
        this.setState({
          eventNameEmpty:'black'
        });
      }
      
      if(this.state.eventDescription == '')
      {
        this.setState({
          submitErr: true,
          eventDescEmpty: 'red',
        });
      }else{
        this.setState({
          eventDescEmpty:'black'
        });
      }

      if(this.state.time == '')
      {
        this.setState({
          submitErr: true,
          eventTimeEmpty: 'red',
        });
      }else{
        this.setState({
          eventTimeEmpty:'black'
        });
      }
    }
 
    render()
    {
      return(
        <KeyboardAvoidingView style = {styles.Container} behavior = "padding">
          <TextInput 
              placeholder={'Event Name'}
              value={this.state.eventName}
              onChangeText={eventName => this.setState({ eventName })}
              style={[styles.loginInput, {borderColor: this.state.eventNameEmpty}]}
              >    
            </TextInput>
            <TextInput placeholder={'Event Description'}
              value={this.state.eventDescription}
              onChangeText={eventDescription => this.setState({ eventDescription })}
              style={[styles.loginInput, {borderColor: this.state.eventDescEmpty}]}
              >
            </TextInput>
            <DatePicker
              style={{width:190}}
              date={this.state.date}
              mode="date"
              placeholder="Event Date"
              format="DD-MM-YYYY"
              minDate={this.currentDate}
              maxDate ="01-01-2030"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              customStyles={{
                dateInput: {
                  borderColor: 'black',
                }
              }}
              onDateChange={(date) => {this.setState({date: date})}}
            ></DatePicker>

            {/* <DatePicker
              style={{width:190, marginTop: 10}}
              date={this.state.time}
              mode="time"
              placeholder="Event Time"
              format="HH:mm"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              customStyles={{
                dateInput: {
                  borderColor: this.state.eventTimeEmpty,
                }
              }}
              minuteInterval={15}
              onDateChange={(time) => {this.setState({time: time})}}
            ></DatePicker> */}
            {
              this.state.submitErr ? <Text style={{color: 'red', marginTop: 10}}>At least box was not filled out</Text> : <Text></Text>
            }
            <View style={{backgroundColor: '#007DE9', marginTop: 15}}>
              <Button title="Submit Event"
                  onPress={this.onSubmitPress.bind(this)}
                  style={styles.submitButton}
                  color = "white"
                >
              </Button>
            </View>
        </KeyboardAvoidingView>
      )
    }
  }
  
  const styles = StyleSheet.create({
    Container: {
      backgroundColor: '#fff',
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
    },
    loginInput: {
      borderColor: 'black',
      borderWidth: 1,
      marginBottom: 10,
      width: "50%",
      height: 40,
      padding: 10,
    },
    submitButton:
    {
      padding: 10,
      marginTop: 40,
      color: '#007DE9'
    }
  });
  
  export default NewEventPage;