import React from 'react';
import { Alert, Text, StyleSheet, Button, TextInput, KeyboardAvoidingView } from 'react-native';

import config from './config';

class RegistrationPage extends React.Component{

    static navigationOptions = {
      title: 'Registration Page',
      };
    constructor(props)
    {
      super(props);
  
      this.state = {
        username: '',
        password: '',
        confirmPassword: '',
        passErr: false,
        registerErr: ''
      };
    }
  
    onLoginPress()
    {
      if(this.state.password === this.state.confirmPassword){
        let user = this.state.username;
        let pass = this.state.password;
        if(config.mode === 'prod'){
          fetch(`${config.baseURL}/register`, {
            method: 'post',
            headers: {
              'Accept': 'application/json, text/plain, */*',
              'Content-Type': 'application/json'
            },
            body: `username=${user}&password=${pass}`
          })
          .then((response) => response.json())
          .then((responseJson) => {
            this.props.navigation.navigate('homePage', {
              username: this.state.username,
              uid: responseJson.success
            });
          })
          .catch((error) => {
            console.log(error.message);
            this.setState({registerErr: error.message});
          });
        }else{
          console.log('submit button pressed');
        }
      }else{
        this.setState({
          passErr: true
        });
      }
    }
  
    render()
    {
      return(
        <KeyboardAvoidingView style = {styles.Container} behavior = "padding">
          <TextInput 
              placeholder={'Username'}
              value={this.state.username}
              onChangeText={username => this.setState({ username })}
              style={styles.loginInput}
              >    
            </TextInput>
            <TextInput placeholder={'Password'}
              value={this.state.password}
              onChangeText={password => this.setState({ password })}
              style={styles.loginInput}
              secureTextEntry={true}
              >
            </TextInput>
            <TextInput placeholder={'Confirm Password'}
              value={this.state.confirmPassword}
              onChangeText={confirmPassword => this.setState({ confirmPassword })}
              style={styles.loginInput}
              secureTextEntry={true}
              >
            </TextInput>
            {
              <Text testID='passwordError' style={{color: 'red'}}>{this.state.passErr ? 'Passwords do not match' : ''}</Text>
            }
            <Button title="Submit"
                testID='button'
                onPress={this.onLoginPress.bind(this)}
                style={styles.loginButton}
              >
            </Button>
            <Text style={{color: 'red'}}>{this.state.registerErr}</Text>
        </KeyboardAvoidingView>
      )
    }
  }
  
  const styles = StyleSheet.create({
    Container: {
      backgroundColor: '#fff',
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
    },
    loginInput: {
      borderColor: 'black',
      borderWidth: 1,
      marginBottom: 10,
      width: "50%",
      height: 40,
      padding: 10,
    },
    loginButton:
    {
      padding: 10,
      backgroundColor: '#007DE9',
    }
  });
  
  export default RegistrationPage;