import React from 'react';
import { Text, Alert, View, StyleSheet, Button, TextInput, KeyboardAvoidingView, ScrollView} from 'react-native';
import TaskSummary from './taskSummary.js';
import { NavigationEvents } from 'react-navigation';
import { checkOwner } from './helper.js';

class TaskPage extends React.Component{

    static navigationOptions = {
      title: 'Task Page',
    };

    constructor(props)
    {
      super(props);
      this.state = {
          reload : 0,
          secondReload: 'test',
      };
    }
 
    //Checks if current user is a member of the task
    isMember(taskJSON, usersName)
    {
        var members = taskJSON.assignees;
        for(var i = 0; i < members.length; ++i)
        {
            if(members[i].name == usersName)
            {
                return(
                    <View>
                        <Text style={{fontSize: 14, textAlign: 'center'}}>
                            You already joined task. Current cost: {"\n"}
                            ${((taskJSON.cost)/(taskJSON.assignees.length)).toFixed(2)}
                        </Text>
                    </View>
                );
            }
        
        }
        return(
            <View style={{flexDirection: 'row', alignItems: 'center'}}>               
                 <View style={{backgroundColor: '#007DE9', marginRight: 10}}>
                    <Button title="Join Task" color="white"
                    onPress = {() => this.joinTask(taskJSON)}
                    >
                    </Button>
                </View>
                <Text style={{fontSize: 12, textAlign: 'center'}}>
                    Task Cost Per Member Would Be: {"\n"} ${((taskJSON.cost)/(taskJSON.assignees.length + 1)).toFixed(2)}
                </Text>
            </View>
        );
    }
    
    joinTask(taskJSON)
    {
        let members = taskJSON.assignees;
        members.push({"name": this.props.navigation.getParam('username'), "uid": this.props.navigation.getParam('uid')});

        let eventJSON = this.props.navigation.getParam('eventJSON', '{}');
        for(let i = 0; i < eventJSON.tasks.length; i++){
            let curTask = eventJSON.tasks[i];
            if(curTask.name === taskJSON.name){
                eventJSON.tasks[i].assignees = members;
            }
        }

        fetch(`${config.baseURL}/event/update`, {
            method: 'post',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: `name=${eventJSON.name}&event=${JSON.stringify(eventJSON)}`
        })
        .then(response => response.json())
        .then(responseJson => {
            console.log(responseJson);
        })
        .catch((error) => {
            console.log(error.message);
            //this.setState({submitErr: true});
        });

        this.setState({reload: this.state.reload + 1});
        return;
    }

    changeStatus(taskJSON)
    {
        let eventJSON = this.props.navigation.getParam('eventJSON', '{}');
        for(let i = 0; i < eventJSON.tasks.length; i++){
            let curTask = eventJSON.tasks[i];
            if(curTask.name === taskJSON.name){
                eventJSON.tasks[i].status = !taskJSON.status;
                if(checkOwner(this.props.navigation.getParam('uid', 'abc123'), eventJSON.tasks[i])){
                    fetch(`${config.baseURL}/event/update`, {
                        method: 'post',
                        headers: {
                            'Accept': 'application/json, text/plain, */*',
                            'Content-Type': 'application/json'
                        },
                        body: `name=${eventJSON.name}&event=${JSON.stringify(eventJSON)}`
                    })
                    .then(response => response.json())
                    .then(responseJson => {
                        console.log(responseJson);
                        this.props.navigation.navigate('eventScreen', {
                            username: this.props.navigation.getParam('username'),
                            uid: this.props.navigation.getParam('uid'),
                            eventJSON: eventJSON
                          });
                    })
                    .catch((error) => {
                        console.log(error.message);
                        //this.setState({submitErr: true});
                    });
            
                    return;
                }else{
                    Alert.alert('Only the owner of the task can change the status');
                    return;
                }
            }
        }
        Alert.alert('Oops, something went wrong!');
    }

    reloadPage()
    {
        this.setState({reload: this.state.reload + 1});
        return;
    }

    render()
    {
        const taskJSON = this.props.navigation.getParam('task');
        return(
            <View style={styles.Container}>
                <NavigationEvents onDidFocus={() => this.reloadPage()}/>
                <View style={{flex: 1.5}}>
                    <TaskSummary task={taskJSON} navigation={this.props.navigation}>
                    </TaskSummary>      
                </View>
                <View style={{flex: 3, flexDirection: 'column', alignItems: 'center', justifyContent: 'space-around'}}>
                    {this.isMember(taskJSON, this.props.navigation.getParam('username'))}
                    <View style={{backgroundColor: '#007DE9'}}>
                        <Button title="Change Task Status" color="white"
                        onPress = {() => this.changeStatus(taskJSON)}
                        > 
                        </Button>
                    </View>
                    <View style={{backgroundColor: '#007DE9'}}>
                        <Button title="Edit/Delete Task" color="white"
                        onPress = {() => this.props.navigation.navigate('editTaskScreen', {
                            username: this.props.navigation.getParam('username', "TestUser"),
                            uid: this.props.navigation.getParam('uid', "654321"),
                            eventJSON: this.props.navigation.getParam('eventJSON', '{}'),
                            taskJSON: taskJSON
                          })}> 
                        </Button>
                    </View>
                </View>
                <View style={{flex: 2, alignItems: 'center'}}>
                    <View style={{height: 20}}>
                        <Text>
                            Task Participants:
                        </Text>
                    </View>
                    <ScrollView style={{padding: 20}}>
                        {taskJSON.assignees.map(t => {
                            return(
                                <Text key={t.name}>
                                    {t.name}
                                </Text>
                            );

                        })}
                    </ScrollView>
                </View>
            </View>                
        )
    }
  }
  
  const styles = StyleSheet.create({
    Container: {
      flex: 1,
    },
  });
  
  export default TaskPage;