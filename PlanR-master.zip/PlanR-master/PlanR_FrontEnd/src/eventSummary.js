import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import PropTypes from 'prop-types';
import { green } from 'ansi-colors';




class EventTitleText extends React.Component{
    constructor(props){
        super(props);
    }
    render()
    {
        if(this.props.status)
        {
            return(
                    <Text style = {styles.titleTextReady}>
                        {this.props.title}
                    </Text>
            )
        }
        else{
            return(
                <Text style = {styles.titleTextNotReady}>
                    {this.props.title}
                </Text>
        )
        }
    }
}
//Should always be passed a prop of event that is a JSON object of event
class EventSummary extends React.Component{
    constructor(props) {
        super(props);
        }

    render()
    {
        const eventJSON = this.props.event;

        //How many lines of the description to show. By default is 2
        if(this.props.descSize == null)
            {this.props.descSize = 2;}
        return(
                <View style = {[styles.InfoContainer, this.props.style]}>
                    <View style={{flex: 3}}>
                        <View style={{flex: 1}}>
                            <EventTitleText title={eventJSON.name} status={eventJSON.status}>
                            </EventTitleText>
                        </View>
                        <View style={{flex: 3, flexDirection: 'row',}}>
                            <View style={{flex: 2, justifyContent: 'space-between'}}>
                                <View style={{flex:1}}>
                                    <Text style={{fontSize: 12, color: 'grey', flex:1}} numberOfLines= {1}>
                                        {eventJSON.date}
                                    </Text>
                                </View>
                                <View style={{flex:1.2}}></View> 
                                {/*Empty view, there has to be a better way */}
                                <View style={{flex:2}}>
                                    <Text style={{fontSize: 12, color: 'black', flex:1, }} numberOfLines= {this.props.descSize}>
                                        {eventJSON.description}
                                    </Text>
                                </View>
                            </View>
                        </View>
                    </View>
                    <View style={{flex: 1}}>
                        <Text style={{fontSize: 12, color: 'grey', flex: 1}} numberOfLines= {2}>
                            Owner: {"\n"}{eventJSON.owner.name}
                        </Text>
                    </View>
                </View>
        )
    }
}

EventSummary.propTypes = {
    event: PropTypes.object,
  };

const styles = StyleSheet.create({
  Container: {
    //height: 100,
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    borderBottomStartRadius: 0,
    marginTop: "2%",
  },
  InfoContainer: {
      marginLeft: 10,
      marginRight: 10,
      //backgroundColor: 'purple',
      flex:1,
      flexDirection: 'row',
  },
  titleTextReady: {
    fontSize: 18,
    //fontWeight: 'bold',
    color: 'green',
  },
  titleTextNotReady: {
    fontSize: 18,
    //fontWeight: 'bold',
    color: 'red',
  }
});

export default EventSummary;
