import React from 'react';
import {Image, StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import PropTypes from 'prop-types';




//Should always be passed a prop of event that is a JSON object of event
class TaskSummary extends React.Component{
    constructor(props) {
        super(props);
        this.state={
            taskColor: "green", //This needs to be changed so it can be red also
            uri: require('../assets/Check.png')
        };
        }
    
    componentDidMount()
        {
            if(!this.props.task.status)
            {
                this.setState({
                    uri: require('../assets/ExMark.png'),
                    taskColor: "red"
                });
            }else{
                this.setState({
                    uri: require('../assets/Check.png'),
                    taskColor: "green"
                });
            }
        }

    //Checks if current user is a member of the task
    isMember(taskJSON, usersName)
    {
        var members = taskJSON.assignees;
        for(var i = 0; i < members.length; ++i)
        {
            if(members[i].name == usersName)
            {
                return(
                    <View style={{flex: 1, alignItems: "flex-start", justifyContent: "center"}}>
                        <Text style={{fontSize: 14, color: "gray"}}>
                            Yes {"\n"}
                        </Text>
                    </View>
                );
            }
        
        }

        return(
            <View style={{flex: 1, alignItems: "flex-start", justifyContent: "center"}}>
                <Text style={{fontSize: 14, color: "gray"}}>
                    No {"\n"}
                </Text>
            </View>
        );
    }
    render()
    {
        const taskJSON = this.props.task;

        //How many lines of the description to show. By default is 2
        return(
            <View style={styles.Container}>
                
                <View style={{flex: 1}}>
                    <View style={{flex: 1.5, flexDirection: 'row'}}>
                        <View style={{flex: .75, flexDirection:'column'}}>
                            <View style={{flex: 1.5}}>
                                <Image
                                resizeMode="contain"
                                style={{flex: 1, height: undefined, width: undefined,}} 
                                source={this.state.uri}>
                                </Image>
                            </View>
                            <View style={{flex: 1}}>

                            </View>
                        </View>
                        <View style={{flex: 3}}>
                            <View style={{flex: 1}}>
                                <Text numberOfLines={1} style={{fontSize: 18, color: this.state.taskColor}} >
                                    {taskJSON.name}
                                </Text>
                            </View>
                            <View style={{flex: 1}}>
                                <Text numberOfLines={1} style={{fontSize: 14, color: 'grey'}}>
                                    Total Task Cost: ${taskJSON.cost}
                                </Text>
                            </View>
                            <View style={{flex: 1}}>
                                <Text numberOfLines={1} style={{fontSize: 14, color: 'grey'}}>
                                    Task Cost Per Member: ${((taskJSON.cost)/(taskJSON.assignees.length)).toFixed(2)}
                                </Text>
                            </View>
                        </View>
                        <View style={{flex: 1}}>
                            <Text style={{fontSize: 12, color: 'grey'}}>
                                Are you a member:
                            </Text>
                            {this.isMember(taskJSON, this.props.navigation.getParam('username'))}
                        </View>
                    </View>
                    <View style={{flex: 1, paddingLeft: 5}}> 
                        <Text numberOfLines={2} style={{fontSize: 12, color: 'black'}}>
                            {taskJSON.description}
                        </Text>
                    </View>
                </View>
            </View>
        )
    }
}

TaskSummary.propTypes = {
    event: PropTypes.object,
  };

const styles = StyleSheet.create({
  Container: {
    //height: 100,
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    borderBottomStartRadius: 0,
    marginTop: "2%",
    flexDirection: 'row',
  },

});

export default TaskSummary;
