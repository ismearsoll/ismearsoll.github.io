import React from 'react';
import { Text, Alert, View, StyleSheet, Button, TextInput, KeyboardAvoidingView } from 'react-native';
import DatePicker from 'react-native-datepicker';

import config from './config';
import { checkAdmin, checkOwner } from './helper';

class EditEventPage extends React.Component{

    static navigationOptions = {
      title: 'Edit Event Page',
    };

    constructor(props)
    {
      super(props);
  
      this.state = {
        eventName: '',
        date: '',
        eventDescription: '',
        time: '',
        submitErr: false,
        eventNameEmpty: 'black',   
        eventDescEmpty: 'black',
        eventTimeEmpty: 'black',     
      };
    }

    componentDidMount()
    {
      const eventJSON = this.props.navigation.getParam('eventJSON');
      this.setState({
        eventName: eventJSON.name,
        date: eventJSON.date,
        eventDescription: eventJSON.description,
        time: eventJSON.time,
      });
    }

    onDeletePress()
    {
      let eventJSON = this.props.navigation.getParam('eventJSON');
      if(checkOwner(this.props.navigation.getParam('uid'), eventJSON)){
        fetch(`${config.baseURL}/event/delete`, {
          method: 'post',
          headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
          },
          body: `uid=${this.props.navigation.getParam('uid')}&name=${this.state.eventName}`
        })
        .then(response => response.json())
        .then(responseJson => {
          console.log(responseJson);
          this.props.navigation.navigate('homePage', {
            username: this.props.navigation.getParam('username'),
            uid: this.props.navigation.getParam('uid')
          });
        })
        .catch((error) => {
          console.log(error.message);
          this.setState({submitErr: true});
        });
      }else{
        this.setState({submitErr: true});
      }
    }
    
    onSubmitPress()
    {
      let eventJSON = this.props.navigation.getParam('eventJSON');
      //If admin
      if(checkAdmin(this.props.navigation.getParam('uid'), eventJSON)){
        //If all inputs used
        if(this.state.eventName != '' && this.state.date !='' && this.state.eventDescription != '' && this.state.time != '')
        {
          this.setState({
            submitErr: false,
            eventNameEmpty: 'black',
            eventDescEmpty: 'black',
            eventTimeEmpty: 'black'
          });

          const username = this.props.navigation.getParam('username');
          const uid = this.props.navigation.getParam('uid');

          let newEventJSON = {
            name: this.state.eventName,
            owner: eventJSON.owner,
            admins: eventJSON.admins,
            participants: eventJSON.participants,
            tasks: eventJSON.tasks,
            description: this.state.eventDescription,
            status: false,
            date: this.state.date,
            time: this.state.time
          }

          console.log(this.state.submitErr);
          if(config.mode === 'dev' && !this.state.submitErr){
            Alert.alert(JSON.stringify(newEventJSON));
          }else if(!this.state.submitErr){
            console.log(newEventJSON);
            fetch(`${config.baseURL}/event/update`, {
              method: 'post',
              headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
              },
              body: `name=${eventJSON.name}&event=${JSON.stringify(newEventJSON)}`
            })
            .then(response => response.json())
            .then(responseJson => {
              console.log(responseJson);
              this.props.navigation.navigate('eventScreen', {
                username: this.props.navigation.getParam('username'),
                uid: this.props.navigation.getParam('uid'),
                eventJSON: newEventJSON
              });
            })
            .catch((error) => {
              console.log(error.message);
              this.setState({submitErr: true});
            });
          }
          return;
        }

        if(this.state.eventName == '')
        {
          this.setState({
            submitErr: true,
            eventNameEmpty: 'red',
          });
        }else{
          this.setState({
            eventNameEmpty:'black'
          });
        }
        
        if(this.state.eventDescription == '')
        {
          this.setState({
            submitErr: true,
            eventDescEmpty: 'red',
          });
        }else{
          this.setState({
            eventDescEmpty:'black'
          });
        }

        if(this.state.time == '')
        {
          this.setState({
            submitErr: true,
            eventTimeEmpty: 'red',
          });
        }else{
          this.setState({
            eventTimeEmpty:'black'
          });
        }
      }
    }
 
    render()
    {
      return(
        <KeyboardAvoidingView style = {styles.Container} behavior = "padding">
          <TextInput 
              placeholder={'Event Name'}
              value={this.state.eventName}
              onChangeText={eventName => this.setState({ eventName })}
              style={[styles.loginInput, {borderColor: this.state.eventNameEmpty}]}
              >    
            </TextInput>
            <TextInput placeholder={'Event Description'}
              value={this.state.eventDescription}
              onChangeText={eventDescription => this.setState({ eventDescription })}
              style={[styles.loginInput, {borderColor: this.state.eventDescEmpty}]}
              >
            </TextInput>
            <DatePicker
              style={{width:190}}
              date={this.state.date}
              mode="date"
              placeholder="Event Date"
              format="DD-MM-YYYY"
              minDate={this.currentDate}
              maxDate ="01-01-2030"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              customStyles={{
                dateInput: {
                  borderColor: 'black',
                }
              }}
              onDateChange={(date) => {this.setState({date: date})}}
            ></DatePicker>

            {/* <DatePicker
              style={{width:190, marginTop: 10}}
              date={this.state.time}
              mode="time"
              placeholder="Event Time"
              format="HH:mm"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              customStyles={{
                dateInput: {
                  borderColor: this.state.eventTimeEmpty,
                }
              }}
              minuteInterval={15}
              onDateChange={(time) => {this.setState({time: time})}}
            ></DatePicker> */}
            {
              this.state.submitErr ? <Text style={{color: 'red', marginTop: 10}}>At least box was not filled out</Text> : <Text></Text>
            }
            <View style={{backgroundColor: '#007DE9', marginTop: 15}}>
              <Button title="Submit Changes to Event"
                  onPress={this.onSubmitPress.bind(this)}
                  style={styles.submitButton}
                  color = "white"
                >
              </Button>
            </View>
            <View style={{backgroundColor: '#DE070C', marginTop: 15}}>
              <Button title="Delete Event"
                  onPress={this.onDeletePress.bind(this)}
                  style={styles.submitButton}
                  color = "white"
                >
              </Button>
            </View>
        </KeyboardAvoidingView>
      )
    }
  }
  
  const styles = StyleSheet.create({
    Container: {
      backgroundColor: '#fff',
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
    },
    loginInput: {
      borderColor: 'black',
      borderWidth: 1,
      marginBottom: 10,
      width: "50%",
      height: 40,
      padding: 10,
    },
    submitButton:
    {
      padding: 10,
      marginTop: 40,
      color: '#007DE9'
    }
  });
  
  export default EditEventPage;