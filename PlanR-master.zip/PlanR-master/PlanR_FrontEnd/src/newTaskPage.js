import React from 'react';
import { Text, Alert, View, StyleSheet, Button, TextInput, KeyboardAvoidingView } from 'react-native';
import DatePicker from 'react-native-datepicker';
import { checkAdmin } from './helper';

class NewTaskPage extends React.Component{

    static navigationOptions = {
      title: 'Create New Task',
    };

    constructor(props)
    {
      super(props);
  
      this.state = {
        taskName: '',
        taskCost: '',
        taskDescription: '',
        taskLimit: '',
        submitErr: false,
        taskNameEmpty: 'black',   
        taskDescEmpty: 'black',
        taskCostEmpty: 'black',  
        taskLimitEmpty: 'black',   
      };
    }

    onLoginPress()
    {
      //If no input is left empty
      if(this.state.taskName != '' && this.state.taskDescription !='' && this.state.taskCost!= '' && this.state.taskLimit != '')
      {
        let eventJSON = this.props.navigation.getParam('eventJSON', "{}");

        const username = this.props.navigation.getParam('username');
        const uid = this.props.navigation.getParam('uid');

        //Create the JSON representing the new task
        let newTaskJSON = {
          name: this.state.taskName,
          owner: {
            uid: uid,
            name: username
          },
          assignees: [
            {
              uid: uid,
              name: username
            }
          ],
          description: this.state.taskDescription,
          limit: this.state.taskLimit,
          status: false,
          cost: this.state.taskCost
        }
        //Push that task into the task array of the event JSON
        eventJSON.tasks.push(newTaskJSON);

        this.setState({
          submitErr: false,
          taskNameEmpty: 'black',
          taskDescEmpty: 'black',
          taskCostEmpty: 'black',
          taskLimitEmpty: 'black',
        });

        //If the user is an admin for the event, add the updated event to the database
        if(config.mode === 'prod'){
          if(checkAdmin(this.props.navigation.getParam('uid'), eventJSON)){
            fetch(`${config.baseURL}/event/update`, {
              method: 'post',
              headers: {
                  'Accept': 'application/json, text/plain, */*',
                  'Content-Type': 'application/json'
              },
              body: `name=${eventJSON.name}&event=${JSON.stringify(eventJSON)}`
            })
            .then(response => response.json())
            .then(responseJson => {
                console.log(responseJson);
            })
            .catch((error) => {
                console.log(error);
                this.setState({submitErr: true});
            });
          }else{
            this.setState({submitErr: true});
            console.log('User is not admin');
          }
        }else{
          Alert.alert(JSON.stringify(newTaskJSON));
        }
        return;
      }

      //All of the following works to highlight what box user who was providing input missed
      if(this.state.taskName == '')
      {
        this.setState({
          submitErr: true,
          taskNameEmpty: 'red',
        });
      }
      else
        this.setState({taskNameEmpty:'black'})
      
      if(this.state.taskDescription == '')
      {
        this.setState({
          submitErr: true,
          taskDescEmpty: 'red',
        });
      }
      else
        this.setState({taskDescEmpty:'black'})

      if(this.state.taskCost == '')
      {
        this.setState({
          submitErr: true,
          taskCostEmpty: 'red',
        });
      }
      else
        this.setState({taskCostEmpty:'black'})

      if(this.state.taskLimit == '')
      {
        this.setState({
          submitErr: true,
          taskLimitEmpty: 'red',
        });
      }
      else
        this.setState({taskLimitEmpty:'black'})
    }
 

    render()
    {
      return(
        <KeyboardAvoidingView style = {styles.Container} behavior = "padding">
          <TextInput 
              placeholder={'Task Name'}
              value={this.state.taskName}
              onChangeText={taskName => this.setState({ taskName })}
              style={[styles.loginInput, {borderColor: this.state.taskNameEmpty}]}
              >    
            </TextInput>
            <TextInput placeholder={'Task Description'}
              value={this.state.taskDescription}
              onChangeText={taskDescription => this.setState({ taskDescription })}
              style={[styles.loginInput, {borderColor: this.state.taskDescEmpty}]}
              >
            </TextInput>
            {/* Inputing cost is next: */}
            <TextInput placeholder={'Task Cost'}
              keyboardType={'numeric'}
              value={this.state.taskCost}
              onChangeText={taskCost => this.setState({taskCost})}
              style={[styles.loginInput, {borderColor: this.state.taskCostEmpty}]}
              >
            </TextInput>
            <TextInput placeholder={'Task Participant Limit'}
              keyboardType={'numeric'}
              value={this.state.taskLimit}
              onChangeText={taskLimit => this.setState({taskLimit})}
              style={[styles.loginInput, {borderColor: this.state.taskLimitEmpty}]}
              >
            </TextInput>
            {
              this.state.submitErr ? <Text style={{color: 'red', marginTop: 10}}>At least one box was not filled out</Text> : <Text></Text>
            }
            <View style={{backgroundColor: '#007DE9', marginTop: 15}}>
              <Button title="Submit Task"
                  onPress={this.onLoginPress.bind(this)}
                  style={styles.submitButton}
                  color = "white"
                >
              </Button>
            </View>
        </KeyboardAvoidingView>
      )
    }
  }
  
  const styles = StyleSheet.create({
    Container: {
      backgroundColor: '#fff',
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
    },
    loginInput: {
      borderWidth: 1,
      marginBottom: 10,
      width: "50%",
      height: 40,
      padding: 10,
    },
    submitButton:
    {
      padding: 10,
      marginTop: 40,
      //backgroundColor: '#007DE9',
    }
  });
  
  export default NewTaskPage;