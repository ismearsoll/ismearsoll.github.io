export default config = {
    mode: 'dev', //Should be 'dev' or 'prod'
    baseURL: 'http://192.227.220.41:30000' //URL to the API
}