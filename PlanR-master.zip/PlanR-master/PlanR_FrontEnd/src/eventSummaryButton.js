import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import PropTypes from 'prop-types';
import { green } from 'ansi-colors';
import EventSummary from './eventSummary.js'




//Should always be passed a prop of event that is a JSON object of event
class EventSummaryButton extends React.Component{
    constructor(props) {
        super(props);
        }

    onEventPress()
    {
        this.props.navigation.navigate('eventScreen', {eventJSON: this.props.event,
            username: this.props.navigation.getParam('username', 'TestUser'),
            uid: this.props.navigation.getParam('uid', '654321')
            });
    }

    render()
    {
        const eventJSON = this.props.event;
        return(
            <TouchableOpacity 
                onPress={this.onEventPress.bind(this)} 
                style = {[styles.Container, this.props.style]}>
                <EventSummary event={eventJSON}>
                </EventSummary>
            </TouchableOpacity>
        )
    }
}

EventSummaryButton.propTypes = {
    event: PropTypes.object,
  };

const styles = StyleSheet.create({
  Container: {
    height: 100,
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    borderBottomStartRadius: 0,
    marginTop: "2%",
  },
});

export default EventSummaryButton;
