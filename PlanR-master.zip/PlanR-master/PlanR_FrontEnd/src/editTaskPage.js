import React from 'react';
import { Text, Alert, View, StyleSheet, Button, TextInput, KeyboardAvoidingView } from 'react-native';
import { checkOwner } from './helper';

class EditTaskPage extends React.Component{

    static navigationOptions = {
      title: 'Create New Task',
    };

    constructor(props)
    {
      super(props);
  
      this.state = {
        taskName: '',
        taskCost: '',
        taskDescription: '',
        taskLimit: '',
        submitErr: false,
        taskNameEmpty: 'black',   
        taskDescEmpty: 'black',
        taskCostEmpty: 'black',  
        taskLimitEmpty: 'black',   
      };
    }

    onSubmitPress()
    {
      if(this.state.taskName != '' && this.state.taskDescription !='' && this.state.taskCost!= '' && this.state.taskLimit != '')
      {
        const uid = this.props.navigation.getParam('uid');

        let taskJSON = this.props.navigation.getParam('taskJSON', '{}');
        let newTaskJSON = taskJSON;

        newTaskJSON.name = this.state.taskName;
        newTaskJSON.description = this.state.taskDescription;
        newTaskJSON.limit = this.state.taskLimit;
        newTaskJSON.cost = this.state.taskCost;

        if(checkOwner(uid, taskJSON)){
          let eventJSON = this.props.navigation.getParam('eventJSON', '{}');
          
          for(let i = 0; i < eventJSON.tasks.length; i++){
            let curTask = eventJSON.tasks[i];
            if(curTask.name === taskJSON.name){
              eventJSON.tasks[i] = newTaskJSON;
            }
          }

          fetch(`${config.baseURL}/event/update`, {
            method: 'post',
            headers: {
              'Accept': 'application/json, text/plain, */*',
              'Content-Type': 'application/json'
            },
            body: `name=${eventJSON.name}&event=${JSON.stringify(eventJSON)}`
          })
          .then(response => response.json())
          .then(responseJson => {
            console.log(responseJson);
            this.props.navigation.navigate('eventScreen', {
              username: this.props.navigation.getParam('username'),
              uid: this.props.navigation.getParam('uid'),
              eventJSON: eventJSON
            });
          })
          .catch((error) => {
            console.log(error.message);
            this.setState({submitErr: true});
          });
        }else{
          this.setState({submitErr: true});
        }

        this.setState({
          submitErr: false,
          taskNameEmpty: 'black',
          taskDescEmpty: 'black',
          taskCostEmpty: 'black',
          taskLimitEmpty: 'black',
        });
        return;
      }

      //All of the following works to highlight what box user who was providing input missed
      if(this.state.taskName == '')
      {
        this.setState({
          submitErr: true,
          taskNameEmpty: 'red',
        });
      }
      else
        this.setState({taskNameEmpty:'black'})
      
      if(this.state.taskDescription == '')
      {
        this.setState({
          submitErr: true,
          taskDescEmpty: 'red',
        });
      }
      else
        this.setState({taskDescEmpty:'black'})

      if(this.state.taskCost == '')
      {
        this.setState({
          submitErr: true,
          taskCostEmpty: 'red',
        });
      }
      else
        this.setState({taskCostEmpty:'black'})

      if(this.state.taskLimit == '')
      {
        this.setState({
          submitErr: true,
          taskLimitEmpty: 'red',
        });
      }
      else
        this.setState({taskLimitEmpty:'black'})
    }
 
    componentDidMount()
    {
        var taskJSON = this.props.navigation.getParam('taskJSON');
        this.setState({
            taskName: taskJSON.name,
            taskCost: (taskJSON.cost).toString(),
            taskDescription: taskJSON.description,
            taskLimit: (taskJSON.limit).toString(),
        });
    }

    onDeletePress()
    {
      let taskJSON = this.props.navigation.getParam('taskJSON');

      if(checkOwner(this.props.navigation.getParam('uid'), taskJSON)){
        let eventJSON = this.props.navigation.getParam('eventJSON', '{}');
        
        for(let i = 0; i < eventJSON.tasks.length; i++){
          let curTask = eventJSON.tasks[i];
          if(curTask.name === taskJSON.name){
            eventJSON.tasks.splice(i, 1); //Splice that task out of the array in the event JSON
          }
        }

        fetch(`${config.baseURL}/event/update`, {
          method: 'post',
          headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
          },
          body: `name=${eventJSON.name}&event=${JSON.stringify(eventJSON)}`
        })
        .then(response => response.json())
        .then(responseJson => {
          console.log(responseJson);
          this.props.navigation.navigate('eventScreen', {
            username: this.props.navigation.getParam('username'),
            uid: this.props.navigation.getParam('uid'),
            eventJSON: eventJSON
          });
        })
        .catch((error) => {
          console.log(error.message);
          this.setState({submitErr: true});
        });
      }else{
        this.setState({submitErr: true});
      }
    }

    render()
    {
      return(
        <KeyboardAvoidingView style = {styles.Container} behavior = "padding">
          <TextInput 
              placeholder={'Task Name'}
              value={this.state.taskName}
              onChangeText={taskName => this.setState({ taskName })}
              style={[styles.loginInput, {borderColor: this.state.taskNameEmpty}]}
              >    
            </TextInput>
            <TextInput placeholder={'Task Description'}
              value={this.state.taskDescription}
              onChangeText={taskDescription => this.setState({ taskDescription })}
              style={[styles.loginInput, {borderColor: this.state.taskDescEmpty}]}
              >
            </TextInput>
            {/* Inputing cost is next: */}
            <TextInput placeholder={'Task Cost'}
              keyboardType={'numeric'}
              value={this.state.taskCost}
              onChangeText={taskCost => this.setState({taskCost})}
              style={[styles.loginInput, {borderColor: this.state.taskCostEmpty}]}
              >
            </TextInput>
            <TextInput placeholder={'Task Participant Limit'}
              keyboardType={'numeric'}
              value={this.state.taskLimit}
              onChangeText={taskLimit => this.setState({taskLimit})}
              style={[styles.loginInput, {borderColor: this.state.taskLimitEmpty}]}
              >
            </TextInput>
            {
              this.state.submitErr ? <Text style={{color: 'red', marginTop: 10}}>At least one box was not filled out</Text> : <Text></Text>
            }
            <View style={{backgroundColor: '#007DE9', marginTop: 15}}>
              <Button title="Submit Task"
                  onPress={this.onSubmitPress.bind(this)}
                  style={styles.submitButton}
                  color = "white"
                >
              </Button>
            </View>
            <View style={{backgroundColor: '#DE070C', marginTop: 15}}>
              <Button title="Delete Task"
                  onPress={this.onDeletePress.bind(this)}
                  style={styles.submitButton}
                  color = "white"
                >
              </Button>
            </View>
        </KeyboardAvoidingView>
      )
    }
  }
  
  const styles = StyleSheet.create({
    Container: {
      backgroundColor: '#fff',
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
    },
    loginInput: {
      borderWidth: 1,
      marginBottom: 10,
      width: "50%",
      height: 40,
      padding: 10,
    },
    submitButton:
    {
      padding: 10,
      marginTop: 40,
      //backgroundColor: '#007DE9',
    }
  });
  
  export default EditTaskPage;