import React from 'react';
import { StyleSheet, Alert, Text, View, Button, TouchableHighlight, Image} from 'react-native';
import EventSummary from './eventSummary.js';
import TaskSummaryButton from './taskSummaryButton.js'
import { NavigationEvents } from 'react-navigation';
import { ScrollView, ForceTouchGestureHandler } from 'react-native-gesture-handler';

import { checkAdmin, checkOwner } from './helper';

class EventScreen extends React.Component{
    static navigationOptions = {
      title: 'Event Page',
    };
    
    constructor(props)
    {
      super(props);
  
      this.state = {
        reload: 1
      };
    }

    reloadPage()
    {
      this.setState({
        reload: this.state.reload + 1
      });
    }

    ExecutePayment(eventJSON)
    {
      if(checkAdmin(this.props.navigation.getParam('uid', 'abc123'), eventJSON)){
        fetch(`${config.baseURL}/charge`, {
          method: 'post',
          headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
          },
          body: `name=${eventJSON.name}`
        })
        .then(response => response.json())
        .then(responseJson => {
          console.log(responseJson);
          if(responseJson.success){
            eventJSON.status = true;
            fetch(`${config.baseURL}/event/update`, {
              method: 'post',
              headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
              },
              body: `name=${eventJSON.name}&event=${JSON.stringify(eventJSON)}`
            })
            .then(response => response.json())
            .then(responseJson => {
              console.log(responseJson);
            });
          }else{
            console.log(responseJson);
          }
        })
        .catch((error) => {
          console.log(error.message);
          this.setState({submitErr: true});
        });
      }
    }

    render()
    {
      const eventJSON = this.props.navigation.getParam('eventJSON')
      return(
          <View style={styles.Container}>
            <NavigationEvents onDidFocus={() => this.reloadPage()}/>
            <View style={styles.eventHolder}>
              <EventSummary event={eventJSON} descSize={5} style={{marginBottom: 10}}>
              </EventSummary>
            </View>
            <View style ={{height: 20, borderBottomWidth: 1, alignSelf: 'center', fontSize: 16}}>
                <Text> TASKS: {'\n'} {this.props.navigation.getParam('username')}</Text>
            </View>
            <View style={styles.taskHolder}> 
              <ScrollView>
              {
                eventJSON.tasks.map(t => {
                  return(
                    <TaskSummaryButton 
                      key={t.name} 
                      task={t}
                      event={eventJSON}
                      navigation={this.props.navigation} ></TaskSummaryButton>
                  );
                })
              }
              </ScrollView>
            </View>

            <View style={{height: 100, justifyContent: "space-between"}}>
              <View style={{height: 50, justifyContent: "space-between", flexDirection: "row", alignItems: "center"}}> 
                <View style={{flex:1, backgroundColor: '#007DE9', marginTop: 10}}>
                    <Button
                      title= "Edit/Delete Event"
                      color = "white"
                      onPress = {() => this.props.navigation.navigate('editEventScreen', {
                        username: this.props.navigation.getParam('username', "TestUser"),
                        uid: this.props.navigation.getParam('uid', "654321"),
                        eventJSON: eventJSON
                      })}
                      >
                    </Button>
                </View>
                <View style={{flex:.1}}>

                </View>
                <View style={{flex:1, backgroundColor: '#007DE9', marginTop: 10}}>
                    <Button
                      title= "Execute Event"
                      color = "white"
                      onPress = {() => this.ExecutePayment(eventJSON)}
                      >
                    </Button>
                </View>
              </View>
              <View style={{height: 50, justifyContent: "space-between", flexDirection: "row"}}> 
                <View style={{flex:1, backgroundColor: '#007DE9', marginTop: 10}}>
                  <Button
                    title= "View/Add Participants"
                    color = "white"
                    onPress = {() => this.props.navigation.navigate('eventParticipants', {
                      username: this.props.navigation.getParam('username', "TestUser"),
                      uid: this.props.navigation.getParam('uid', "654321"),
                      eventJSON: eventJSON
                    })}
                    >
                  </Button>
                </View>
                <View style= {{flex: .1}}>
                  
                </View>
                <View style={{flex: 1, backgroundColor: '#007DE9', marginTop: 10}}>
                  <Button
                    title= "New Task"
                    color = "white"
                    onPress = {() => this.props.navigation.navigate('newTaskScreen', {
                      username: this.props.navigation.getParam('username', "TestUser"),
                      uid: this.props.navigation.getParam('uid', "654321"),
                      eventJSON: eventJSON
                    })}
                    >
                  </Button>
                </View>
              </View>
            </View>
          </View>
      )
    }
}

const styles = StyleSheet.create({
  Container: {
    flex: 1,

  },
  eventHolder:{
    flex: 1,
  },
  taskHolder: {
    flex: 4,
    marginTop: 10,
  }
});

export default EventScreen;
