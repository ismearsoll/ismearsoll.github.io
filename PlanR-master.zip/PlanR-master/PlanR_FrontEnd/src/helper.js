export const checkParticipant = (participantId, event) => {
    let partList = event.participants;

    for(let i = 0; i < partList.length; i++){
        if(partList[i].uid === participantId) return true;
    }

    return false;
}

export const checkAdmin = (participantId, event) => {
    let adminList = event.admins;

    for(let i = 0; i < adminList.length; i++){
        if(adminList[i].uid === participantId) return true;
    }

    return false;
}

export const checkOwner = (participantId, event) => {
    let owner = event.owner;

    if(owner.uid === participantId) return true;
    else return false;
}