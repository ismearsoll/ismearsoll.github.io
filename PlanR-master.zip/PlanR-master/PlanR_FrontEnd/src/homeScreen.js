import React from 'react';
import { StyleSheet, Alert, Text, View, Button, TouchableHighlight, Image} from 'react-native';
import LogoutHeader from './logoutHeader.js'
import EventSummaryButton from './eventSummaryButton.js'
import { ScrollView } from 'react-native-gesture-handler';
import jsonArrInit from '../assets/jsonDEV.json';
import { NavigationEvents } from 'react-navigation';

import config from './config';
import { checkParticipant } from './helper';

class homeScreen extends React.Component{

    constructor(props) {
      super(props);

      this.state = {
        jsonArr: []
      };
    }

    /*
    static navigationOptions = ({navigation}) =>{
        return {
            headerTitle: <LogoutHeader title = 'Main Event List Page' navigation = {navigation} />
        };
    };*/
    static navigationOptions = {
      title: 'Home Page',
      };

    getEventData(){
      if(config.mode === 'prod')
      {
        //This is will we will do our get to database. Just overwrite the variable this.jsonArr with what we get
        //Should set this.jsonArr
        fetch(`${config.baseURL}/events`)
        .then((response) => response.json())
        .then((responseJson) => {
          console.log(responseJson);
          let unfilteredJsonArr = responseJson.success;
          this.setState({jsonArr: unfilteredJsonArr.filter(object => checkParticipant(this.props.navigation.getParam('uid', 'abc123'), object))});
          console.log(this.state.jsonArr);
        })
        .catch((error) => {
          console.log(error.message);
        });
      }else{
        this.setState({jsonArr: jsonArrInit.success});
      }
    }

    componentDidMount()
    {
      this.getEventData();
    }

    render()
    {
    return(
        <View style={styles.Container}>
          <NavigationEvents onDidFocus={() => this.getEventData()}/>
            {/*<View style={styles.topBar}>
              <Text style={styles.textStyle}>
                  Welcome user: {this.props.navigation.getParam('username', "TestUser")}
              </Text>
              <View>
                  <Button 
                      color = "#007DE9"
                      title = "Edit Profile"
                      onPress = {() => this.props.navigation.navigate('accountScreen')}
                      >
                  </Button>
              </View>
            </View>*/}
            <ScrollView style = {styles.scrollStyle}>
              {
                this.state.jsonArr.map(e => {
                  return(
                    <EventSummaryButton key={e.name} 
                      event={e} 
                      navigation={this.props.navigation} 
                      style={styles.eventSummaryStyle}>
                    </EventSummaryButton>
                  );
                })
              }
            </ScrollView>
            <View style={{alignSelf: "flex-end", backgroundColor: '#007DE9', marginTop: 10}}>
              <Button
                title= "New Event"
                color = "white"
                onPress = {() => this.props.navigation.navigate('newEventScreen', {
                  username: this.props.navigation.getParam('username', "TestUser"),
                  uid: this.props.navigation.getParam('uid', "654321"),
                  eventArray: this.state.jsonArr
                })}
                >
              </Button>
            </View>
            
        </View>
    )
    }
}

const styles = StyleSheet.create({
  Container: {
    backgroundColor: '#fff',
    flex: 1,
    alignItems: "center",
    flexDirection: 'column',
    justifyContent: 'flex-start',
  },
  topBar:{
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 40,
  },
  eventSummaryStyle:{
    //borderBottomWidth: 1,
    //borderColor: 'black',
  },
  scrollStyle:{
    width: "100%",
    borderTopWidth: 1,
  },
  textStyle:{
    fontSize: 20,
    marginRight: 20
  },
});

export default homeScreen;
