import React from 'react';
import { StyleSheet, Alert, Text, View, TouchableOpacity} from 'react-native';
import PropTypes from 'prop-types';
import TaskSummary from './taskSummary.js'

//Should always be passed a prop of event that is a JSON object of event
class TaskSummaryButton extends React.Component{
    constructor(props) {
        super(props);
        }

    onTaskPress()
    {
        this.props.navigation.navigate('taskScreen', {task: this.props.task,
            username: this.props.navigation.getParam('username', 'testUser'),
            uid: this.props.navigation.getParam('uid', '654321'),
            eventJSON: this.props.navigation.getParam('eventJSON', '{}')
        });
    }
    render()
    {
        const taskJSON = this.props.task;
        return(
            <TouchableOpacity 
                onPress={this.onTaskPress.bind(this)}
                style = {styles.Container}>
                <TaskSummary task={taskJSON} navigation={this.props.navigation}>
                </TaskSummary>
            </TouchableOpacity>
        )
    }
}

const styles = StyleSheet.create({
  Container: {
    height: 125,
    flex: 1,
  },
  
  
});

export default TaskSummaryButton;
