import React from 'react';
import { StyleSheet, Text, View, Button} from 'react-native';
import LogoutHeader from './logoutHeader.js'


class accountScreen extends React.Component{
    /*static navigationOptions = ({ navigation}) =>{
        return {
            headerTitle: <LogoutHeader title = 'Account Details Screen' navigation = {navigation} />
        };
    };*/
    static navigationOptions = {
      title: 'Edit Account Profile',
      };
  render()
  {
    return(
    <View style={styles.Container}>
        <View>
            <Text>Haven't implemented functionality here yet</Text>
        </View>
     </View>
    )
  }
}

const styles = StyleSheet.create({
  Container: {
    backgroundColor: '#fff',
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default accountScreen;
