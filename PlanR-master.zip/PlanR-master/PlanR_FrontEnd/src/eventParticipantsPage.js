import React from 'react';
import {Switch, Text, Alert, View, StyleSheet, Button, TextInput, KeyboardAvoidingView } from 'react-native';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';
import { RadioButton } from 'react-native-paper';
import { checkAdmin, checkParticipant } from './helper';

class EventParticipantsPage extends React.Component{

    static navigationOptions = {
      title: 'Event Participants',
      };
    constructor(props)
    {
      super(props);
      this.keyCount = 0;
      this.state = {
        memberName: '',
        inputNameErr: 1,
        checked: 'first',        
      };
    }

    onLoginPress(eventJSON)
    {
        if(checkAdmin(this.props.navigation.getParam('uid'), eventJSON)){
            var newName = this.state.memberName;

            //If user did not fill out the box at all display error on page
            if(newName== '')
            {
                this.setState({inputNameErr: 2})
                return;
            }
            else
            {
                var partObj = eventJSON.participants
                //Test if participant already in events
                for(var i = 0; i < partObj.length; ++i)
                {
                    if(partObj[i].name == newName)
                    {
                        this.setState({inputNameErr: 3})
                        return;
                    }
                }
                
                //If we get a failure we need to set the state inputNameErr to 2 and then return
                let user;

                fetch(`${config.baseURL}/users`)
                .then(response => response.json())
                .then(responseJson => {
                    //Search the user list for the name put in
                    for(let i = 0; i < responseJson.success.length; i++){
                        if(newName === responseJson.success[i].name){
                            user = responseJson.success[i];
                        }
                    }

                    if(!user){ //If user doesn't exist, set error and return
                        this.setState({inputNameErr: 2});
                        return;
                    }
                    
                    //Adds the user to the current jsonObj
                    partObj.push({"name": user.name, "uid": user.uid});
                    this.setState({inputNameErr: 1});
                    eventJSON.participants = partObj;

                    if(this.state.checked == 'second'){
                        let adminObj = eventJSON.admins;
                        adminObj.push({"name": user.name, "uid": user.uid})
                        eventJSON.admins = partObj;
                    }                   

                    //Push changes to database
                    if(config.mode === 'prod'){
                        console.log('here');
                        fetch(`${config.baseURL}/event/update`, {
                            method: 'post',
                            headers: {
                                'Accept': 'application/json, text/plain, */*',
                                'Content-Type': 'application/json'
                            },
                            body: `name=${eventJSON.name}&event=${JSON.stringify(eventJSON)}`
                        })
                        .then(response => response.json())
                        .then(responseJson => {
                            console.log(responseJson);
                        })
                        .catch((error) => {
                            console.log(error);
                        });
                    }else{
                        var temp = JSON.stringify(partObj);
                        Alert.alert('' + temp);
                    }
                })
                .catch((error) => {
                    console.log(error.message);
                    this.setState({inputNameErr: 2});
                });       
            }
        }
    }

    errorOutput(errorNum)
    {
        if(errorNum == 2)
        {
            return(
                <Text style={{color: "red", marginBottom: 10}}>
                    That name is not found
                </Text>
            );
        }
        else if(errorNum == 3)
        {
            return(
                <Text style={{color: "red", marginBottom: 10}}>
                    User already participant in event
                </Text>
            );
        }
        else
        {
            return (
                <View>
                </View>
            );
        }
    }

    getUserStatus(t, eventJSON)
    {
        var ownerOBJ = eventJSON.owner;
        ///Test if t is owner
        if(ownerOBJ.name == t.name)
        {
            return 3;
        }
        //Test if t is admin
        var adminOBJ = eventJSON.admins;
        for(var i = 0; i < adminOBJ.length; ++i)
        {
            if(adminOBJ[i].name == t.name)
            {
                return 2;
            }
        }
        return 1;
    }

    render()
    {
        const eventJSON = this.props.navigation.getParam('eventJSON')
        return(
        <KeyboardAvoidingView style = {styles.Container} behavior = "padding" enabled>
            <View style={{width: "100%", flex: 1, alignItems: "center", justifyContent: "center", borderBottomWidth: 1}}>
                <TextInput placeholder={'New Member Name'}
                    value={this.state.memberName}
                    onChangeText={memberName => this.setState({memberName})}
                    style={styles.inputBox}
                    >
                </TextInput>
                {this.errorOutput(this.state.inputNameErr)
                }
                <View style={{height: 100, width: "80%", marginBottom: 10}}>
                    <TouchableOpacity onPress={() => { this.setState({ checked: 'first' }); }}>
                        <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}}>
                            <RadioButton
                            value="First"
                            status={this.state.checked === 'first' ? 'checked' : 'unchecked'}
                            />
                            <Text>
                                Add as normal member
                            </Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => { this.setState({ checked: 'second' }); }}>
                        <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}}>
                                <RadioButton
                                value="Second"
                                status={this.state.checked === 'second' ? 'checked' : 'unchecked'}
                                />
                                <Text>
                                    Add as Administrator
                                </Text>
                        </View>
                    </TouchableOpacity>
                </View>
                <View style={{height: 40, backgroundColor: '#007DE9'}}>
                    <Button 
                        title="Add New Participant to Event"
                        color="white"
                        onPress={this.onLoginPress.bind(this, eventJSON)}>
                    </Button>
                </View>
            </View>
            <View style={styles.displayCurrent}>
                <View style={{}}>
                    <Text style={{fontSize: 20}}>
                        Current Participants in {eventJSON.name}:
                    </Text>
                </View>
                <ScrollView style={{paddingLeft: 20}}>
                {
                    eventJSON.participants.map(t => {
                            var userStatus = this.getUserStatus(t, eventJSON);
                            //Event Owner
                            if(userStatus == 3)
                            {
                                return(
                                <View key={this.keyCount++} style={{flexDirection: 'row'}}>
                                    <Text style={{fontSize: 14}}key={t.name}>
                                        {t.name} 
                                    </Text> 
                                    <Text style={{fontWeight:'bold'}}>
                                        (Owner) 
                                    </Text>
                                </View>);
                            }
                            //Event Administrator
                            else if(userStatus == 2)
                            {
                                return(
                                    <View key={this.keyCount++} style={{flexDirection: 'row'}}>
                                        <Text style={{fontSize: 14}}key={t.name}>
                                            {t.name} 
                                        </Text> 
                                        <Text style={{fontWeight:'bold'}}>
                                            (Admin) 
                                        </Text>
                                    </View>);
                            }
                            //Normal Event Participant
                            else
                            {
                                return(
                                    <Text style={{fontSize: 14}}key={t.name}>
                                        {t.name} 
                                    </Text>);
                            }
                        
                    })
                }
                                    
                </ScrollView>
            </View>    
        </KeyboardAvoidingView>
        )
    }
  }
  
  const styles = StyleSheet.create({
    Container: {
      backgroundColor: '#fff',
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
    },
    inputBox: {
        borderColor: 'black',
        borderWidth: 1,
        width: "70%",
        height: 40,
        marginBottom: 10,
        padding: 10,
    },
    displayCurrent: {
        width: "100%", 
        flex: 1, 
        alignItems: "center",
    }
  });
  
  export default EventParticipantsPage;